import { supabase } from "../supabaseClient";
import { getGeminiInsights } from "../services/geminiAI";
import { sendEmail } from "./sendEmail"; // see below

// Send the initial outreach email
export async function sendInitialEmail(prospect: any) {
  const prompt = `Write a friendly intro email about our product to ${prospect.name}.`;
  const emailBody = await getGeminiInsights(prompt);
  await sendEmail(prospect.email, "Introducing Our Product", emailBody);

  await supabase.from("prospects").update({
    last_email_sent: new Date().toISOString(),
    followup_count: 0,
    status: "active"
  }).eq("id", prospect.id);
}

// Send a follow-up email
export async function sendFollowUp(prospect: any) {
  const prompt = `Draft a polite follow-up email to ${prospect.name} about our product.`;
  const followUpBody = await getGeminiInsights(prompt);
  await sendEmail(prospect.email, "Just Checking In", followUpBody);

  await supabase.from("prospects").update({
    last_email_sent: new Date().toISOString(),
    followup_count: (prospect.followup_count || 0) + 1
  }).eq("id", prospect.id);
}

// Handle reply from prospect
export async function handleReply(prospect: any, replyText: string) {
  const prompt = `Prospect replied: "${replyText}". Draft a relevant follow-up email.`;
  const responseEmail = await getGeminiInsights(prompt);
  await sendEmail(prospect.email, "Re: Your Interest", responseEmail);

  await supabase.from("prospects").update({
    conversation: [
      ...(prospect.conversation || []),
      { from: "prospect", message: replyText, timestamp: new Date().toISOString() },
      { from: "agent", message: responseEmail, timestamp: new Date().toISOString() }
    ]
  }).eq("id", prospect.id);
}

// Schedule demo (Google Calendar integration, pseudo-code)
export async function scheduleDemo(prospect: any, replyText: string) {
  const prompt = `Extract the proposed meeting date and time from: "${replyText}". Respond in ISO format.`;
  const isoTime = await getGeminiInsights(prompt);

  // Call your Google Calendar API utility here (not shown)
  // await createCalendarEvent({ ... });

  await supabase.from("prospects").update({
    status: "demo_scheduled",
    demo_time: isoTime
  }).eq("id", prospect.id);
}
