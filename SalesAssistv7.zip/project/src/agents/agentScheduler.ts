import { supabase } from "../supabaseClient";
import { sendFollowUp } from "./mailAgent";

export async function processFollowUps() {
  const { data: prospects } = await supabase.from("prospects").select("*").eq("status", "active");
  const now = new Date();

  for (const prospect of prospects || []) {
    const lastSent = new Date(prospect.last_email_sent);
    const daysSince = (now.getTime() - lastSent.getTime()) / (1000 * 60 * 60 * 24);

    if (daysSince >= 3 && (prospect.followup_count || 0) < 3) {
      await sendFollowUp(prospect);
    } else if ((prospect.followup_count || 0) >= 3) {
      await supabase.from("prospects").update({ status: "stopped" }).eq("id", prospect.id);
    }
  }
}
