import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY || "");

export async function getGeminiInsights(query: string) {
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" }); // Use 1.5-flash
  const prompt = `Give me a sales intelligence summary for: ${query}.
    Include: public web info, LinkedIn highlights, recent news, and company background if available.`;
  try {
    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (err) {
    console.error("Gemini API error:", err);
    throw err;
  }
}
