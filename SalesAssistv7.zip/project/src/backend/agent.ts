import express from "express";
import cron from "node-cron";
import { handleReply } from "../agents/mailAgent";
import { processFollowUps } from "../agents/agentScheduler";
import { supabase } from "../supabaseClient";
import { sendEmail } from "../agents/sendEmail";

const app = express();
app.use(express.json());

// Email reply webhook endpoint
app.post("/api/email-reply", async (req, res) => {
  const { to, from, text } = req.body;
  const { data: prospects } = await supabase.from("prospects").select("*").eq("email", from);
  if (prospects && prospects.length > 0) {
    await handleReply(prospects[0], text);
  }
  res.status(200).send("OK");
});

// API endpoint to send an email
app.post("/api/send-email", async (req, res) => {
  const { to, subject, text } = req.body;
  try {
    console.log("API: /api/send-email called", { to, subject });
    await sendEmail(to, subject, text);
    res.status(200).send({ status: "sent" });
  } catch (err: any) {
    console.error("API: Failed to send email", err);
    res.status(500).send({ error: err.message || String(err) });
  }
});

// Cron job for automated follow-ups (runs every hour)
cron.schedule("0 * * * *", async () => {
  await processFollowUps();
});

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT}`);
});

export default app;
