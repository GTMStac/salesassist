import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../supabaseClient';

interface User {
  id: string;
  email: string | null;
  user_metadata?: {
    first_name?: string;
    last_name?: string;
    company?: string;
    name?: string;
  };
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  register: (
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    company: string
  ) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const getSession = async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session?.user) {
        setUser({
          id: data.session.user.id,
          email: data.session.user.email,
          user_metadata: data.session.user.user_metadata,
        });
        setIsAuthenticated(true);
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
      setLoading(false);
    };
    getSession();

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setUser({
          id: session.user.id,
          email: session.user.email,
          user_metadata: session.user.user_metadata,
        });
        setIsAuthenticated(true);
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
    });

    return () => {
      listener?.subscription?.unsubscribe();
    };
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    const { error, data } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setLoading(false);
      throw error;
    }
    if (data.user) {
      setUser({
        id: data.user.id,
        email: data.user.email,
        user_metadata: data.user.user_metadata,
      });
      setIsAuthenticated(true);
      navigate('/dashboard');
    }
    setLoading(false);
  };

  const logout = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signOut();
    setUser(null);
    setIsAuthenticated(false);
    setLoading(false);
    if (error) throw error;
    window.location.href = '/auth';
  };

  const register = async (
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    company: string
  ) => {
    setLoading(true);
    try {
      // 1. Sign up with Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            first_name: firstName,
            last_name: lastName,
            company,
          },
        },
      });
      if (error) throw error;

      // 2. Insert profile data into profiles table
      if (data.user) {
        const { error: insertError } = await supabase
          .from('profiles')
          .insert([{
            id: data.user.id,
            first_name: firstName,
            last_name: lastName,
            company,
          }]);
        if (insertError) throw insertError;

        // 3. Sanitize folder and file names
        const sanitizedCompany = company.replace(/[^a-zA-Z0-9-_]/g, '_');
        const sanitizedFirstName = firstName.replace(/[^a-zA-Z0-9-_]/g, '_');
        const sanitizedLastName = lastName.replace(/[^a-zA-Z0-9-_]/g, '_');
        const userFolder = `${sanitizedFirstName}_${sanitizedLastName}`;

        // 4. Prepare user details as separate files
        const userDetails = {
          firstName,
          lastName,
          email,
          company,
        };

        // 5. Upload each detail as a separate file
        for (const [key, value] of Object.entries(userDetails)) {
          const { error: storageError } = await supabase.storage
            .from('user-details')
            .upload(
              `${sanitizedCompany}/${userFolder}/${key}.txt`,
              value.toString(),
              { contentType: 'text/plain' }
            );
          if (storageError) throw storageError;
        }
      }
    } catch (err: any) {
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin + '/auth/callback',
      },
    });
    setLoading(false);
    if (error) throw error;
    if (data.url) {
      window.location.href = data.url;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        loading,
        login,
        logout,
        register,
        loginWithGoogle,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
