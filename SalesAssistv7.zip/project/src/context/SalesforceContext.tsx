import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../supabaseClient';

// --- Types ---
interface OpportunityType {
  id: string;
  name: string;
  accountId: string;
  accountName: string;
  stage: string;
  amount: number | null;
  closeDate: string;
  probability: number;
  type: string;
}
interface AccountType {
  id: string;
  name: string;
  industry: string;
  website: string;
  phone: string;
  type: string;
  city?: string;
  country?: string;
}
interface ContactType {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  accountId: string;
  title: string;
}
interface LeadType {
  id: string;
  firstName: string;
  lastName: string;
  company: string;
  title: string;
  email: string;
  phone: string;
  status: string;
}

// --- Activity Types ---
interface ActivityType {
  id: string;
  subject: string;
  activityDate?: string;
  status?: string;
  priority?: string;
  description?: string;
  ownerId?: string;
  whatId?: string;
  whoId?: string;
  taskSubtype?: string;
  type?: string;
  callType?: string;
  callDisposition?: string;
  callDurationInSeconds?: number;
}
interface EventType {
  id: string;
  subject: string;
  startDateTime: string;
  endDateTime: string;
  description?: string;
  ownerId?: string;
  whatId?: string;
  whoId?: string;
  location?: string;
}

interface SalesforceContextType {
  leads: LeadType[];
  accounts: AccountType[];
  contacts: ContactType[];
  opportunities: OpportunityType[];
  products: any[];
  activities: ActivityType[];
  calls: ActivityType[];
  emails: ActivityType[];
  tasks: ActivityType[];
  events: EventType[];
  loading: boolean;
  error: string | null;
  isAuthenticated: boolean;
  refreshData: () => Promise<void>;
  getObjectById: (objectType: string, id: string) => any;
  addLead: (leadData: Partial<LeadType>) => Promise<void>;
  addAccount: (accountData: Partial<AccountType>) => Promise<void>; 
}


const SalesforceContext = createContext<SalesforceContextType | undefined>(undefined);

export const useSalesforce = () => {
  const context = useContext(SalesforceContext);
  if (!context) throw new Error('useSalesforce must be used within a SalesforceProvider');
  return context;
};

interface SalesforceProviderProps {
  children: ReactNode;
}

export const SalesforceProvider: React.FC<SalesforceProviderProps> = ({ children }) => {
  const [data, setData] = useState({
    leads: [],
    accounts: [],
    contacts: [],
    opportunities: [],
    products: [],
  });
  const [activities, setActivities] = useState<ActivityType[]>([]);
  const [calls, setCalls] = useState<ActivityType[]>([]);
  const [emails, setEmails] = useState<ActivityType[]>([]);
  const [tasks, setTasks] = useState<ActivityType[]>([]);
  const [events, setEvents] = useState<EventType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const safeJson = async (res: Response) => {
    const clone = res.clone();
    try {
      return await res.json();
    } catch {
      const text = await clone.text();
      throw new Error(`Invalid JSON: ${text}`);
    }
  };

  const fetchSalesforceData = async () => {
    setLoading(true);
    setError(null);

    try {
      const accessToken = localStorage.getItem('sf_access_token');
      const instanceUrl = localStorage.getItem('sf_instance_url');
      const supabaseUserId = (await supabase.auth.getUser()).data.user?.id;

      if (!accessToken || !instanceUrl || !supabaseUserId) {
        throw new Error('Not authenticated with Salesforce');
      }

      const { data: mapping, error: mappingError } = await supabase
        .from('user_mapping')
        .select('salesforce_user_id')
        .eq('supabase_user_id', supabaseUserId)
        .maybeSingle();

      if (mappingError) throw new Error(`Mapping error: ${mappingError.message}`);
      if (!mapping?.salesforce_user_id) throw new Error('User mapping not found');

      const headers = {
        'Authorization': `Bearer ${accessToken}`,
        'sf-instance-url': instanceUrl,
        'sf-user-id': mapping.salesforce_user_id,
        'Content-Type': 'application/json',
      };

      // Fetch all objects and activities in parallel
      const [
        oppRes,
        leadsRes,
        contactsRes,
        accountsRes,
        activitiesRes,
        callsRes,
        emailsRes,
        tasksRes,
        eventsRes
      ] = await Promise.all([
        fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/opportunities`, { headers }),
        fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/leads`, { headers }),
        fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/contacts`, { headers }),
        fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/accounts`, { headers }),
        fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/activities`, { headers }),
        fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/calls`, { headers }),
        fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/emails`, { headers }),
        fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/tasks`, { headers }),
        fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/events`, { headers }),
      ]);

      const [
        oppData,
        leadsData,
        contactsData,
        accountsData,
        activitiesData,
        callsData,
        emailsData,
        tasksData,
        eventsData
      ] = await Promise.all([
        safeJson(oppRes),
        safeJson(leadsRes),
        safeJson(contactsRes),
        safeJson(accountsRes),
        safeJson(activitiesRes),
        safeJson(callsRes),
        safeJson(emailsRes),
        safeJson(tasksRes),
        safeJson(eventsRes),
      ]);

      // Handle errors
      if (
        !oppRes.ok || !leadsRes.ok || !contactsRes.ok || !accountsRes.ok ||
        !activitiesRes.ok || !callsRes.ok || !emailsRes.ok || !tasksRes.ok || !eventsRes.ok
      ) {
        throw new Error(
          (oppData.error ? `Opportunities: ${oppData.error}\n` : '') +
          (leadsData.error ? `Leads: ${leadsData.error}\n` : '') +
          (contactsData.error ? `Contacts: ${contactsData.error}\n` : '') +
          (accountsData.error ? `Accounts: ${accountsData.error}\n` : '') +
          (activitiesData.error ? `Activities: ${activitiesData.error}\n` : '') +
          (callsData.error ? `Calls: ${callsData.error}\n` : '') +
          (emailsData.error ? `Emails: ${emailsData.error}\n` : '') +
          (tasksData.error ? `Tasks: ${tasksData.error}\n` : '') +
          (eventsData.error ? `Events: ${eventsData.error}\n` : '')
        );
      }

      const opportunities = (oppData.records || []).map((opp: any) => ({
        id: opp.Id,
        name: opp.Name,
        stage: opp.StageName,
        amount: opp.Amount,
        closeDate: opp.CloseDate,
        probability: opp.Probability || 0,
        type: opp.Type,
        accountId: opp.AccountId,
        accountName: opp.Account?.Name || '',
      }));

      const leads = (leadsData.records || []).map((lead: any) => ({
        id: lead.Id,
        firstName: lead.FirstName,
        lastName: lead.LastName,
        company: lead.Company,
        title: lead.Title,
        email: lead.Email,
        phone: lead.Phone,
        status: lead.Status
      }));

      const contacts = (contactsData.records || []).map((contact: any) => ({
        id: contact.Id,
        firstName: contact.FirstName,
        lastName: contact.LastName,
        email: contact.Email,
        phone: contact.Phone,
        accountId: contact.AccountId,
        title: contact.Title
      }));

      const accounts = (accountsData.records || []).map((account: any) => ({
        id: account.Id,
        name: account.Name,
        industry: account.Industry,
        website: account.Website,
        phone: account.Phone,
        type: account.Type,
        city: account.BillingCity,
        country: account.BillingCountry
      }));

      setData({ leads, accounts, contacts, opportunities, products: [] });

      setActivities((activitiesData.records || []).map((a: any) => ({
        id: a.Id,
        subject: a.Subject,
        activityDate: a.ActivityDate,
        status: a.Status,
        priority: a.Priority,
        description: a.Description,
        ownerId: a.OwnerId,
        whatId: a.WhatId,
        whoId: a.WhoId,
        taskSubtype: a.TaskSubtype,
        type: a.Type,
        callType: a.CallType,
        callDisposition: a.CallDisposition,
        callDurationInSeconds: a.CallDurationInSeconds,
      })));

      setCalls((callsData.records || []).map((a: any) => ({
        id: a.Id,
        subject: a.Subject,
        activityDate: a.ActivityDate,
        status: a.Status,
        priority: a.Priority,
        description: a.Description,
        ownerId: a.OwnerId,
        whatId: a.WhatId,
        whoId: a.WhoId,
        taskSubtype: a.TaskSubtype,
        type: a.Type,
        callType: a.CallType,
        callDisposition: a.CallDisposition,
        callDurationInSeconds: a.CallDurationInSeconds,
      })));

      setEmails((emailsData.records || []).map((a: any) => ({
        id: a.Id,
        subject: a.Subject,
        activityDate: a.ActivityDate,
        status: a.Status,
        priority: a.Priority,
        description: a.Description,
        ownerId: a.OwnerId,
        whatId: a.WhatId,
        whoId: a.WhoId,
        taskSubtype: a.TaskSubtype,
        type: a.Type,
      })));

      setTasks((tasksData.records || []).map((a: any) => ({
        id: a.Id,
        subject: a.Subject,
        activityDate: a.ActivityDate,
        status: a.Status,
        priority: a.Priority,
        description: a.Description,
        ownerId: a.OwnerId,
        whatId: a.WhatId,
        whoId: a.WhoId,
        taskSubtype: a.TaskSubtype,
        type: a.Type,
      })));

      setEvents((eventsData.records || []).map((e: any) => ({
        id: e.Id,
        subject: e.Subject,
        startDateTime: e.StartDateTime,
        endDateTime: e.EndDateTime,
        description: e.Description,
        ownerId: e.OwnerId,
        whatId: e.WhatId,
        whoId: e.WhoId,
        location: e.Location,
      })));

      setIsAuthenticated(true);
      setError(null);

    } catch (err: any) {
      console.error('Salesforce data fetch error:', err);
      setError(err.message || 'Failed to fetch Salesforce data');
      setIsAuthenticated(false);
    } finally {
      setLoading(false);
    }
  };

  const addLead = async (leadData: Partial<LeadType>) => {
    setLoading(true);
    setError(null);
    try {
      const accessToken = localStorage.getItem('sf_access_token');
      const instanceUrl = localStorage.getItem('sf_instance_url');
      const supabaseUserId = (await supabase.auth.getUser()).data.user?.id;

      if (!accessToken || !instanceUrl || !supabaseUserId) {
        throw new Error('Not authenticated with Salesforce');
      }

      const { data: mapping, error: mappingError } = await supabase
        .from('user_mapping')
        .select('salesforce_user_id')
        .eq('supabase_user_id', supabaseUserId)
        .maybeSingle();

      if (mappingError) throw new Error(`Mapping error: ${mappingError.message}`);
      if (!mapping?.salesforce_user_id) throw new Error('User mapping not found');

      const headers = {
        'Authorization': `Bearer ${accessToken}`,
        'sf-instance-url': instanceUrl,
        'sf-user-id': mapping.salesforce_user_id,
        'Content-Type': 'application/json',
      };

      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/leads`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify({
            FirstName: leadData.firstName,
            LastName: leadData.lastName,
            Company: leadData.company,
            Phone: leadData.phone,
            Email: leadData.email,
            Title: leadData.title,
            Status: leadData.status,
          }),
        }
      );

      const result = await res.json();
      if (!res.ok) throw new Error(result.error || 'Failed to create lead');

      // Refresh leads after adding
      await fetchSalesforceData();
    } catch (err: any) {
      setError(err.message || 'Failed to add lead');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const getObjectById = (objectType: string, id: string) => {
    const objects = data[objectType as keyof typeof data] || [];
    return objects.find((obj: any) => obj.id === id) || null;
  };

  useEffect(() => {
    const checkAuth = () => {
      const accessToken = localStorage.getItem('sf_access_token');
      const instanceUrl = localStorage.getItem('sf_instance_url');
      if (accessToken && instanceUrl) {
        setIsAuthenticated(true);
        fetchSalesforceData();
      } else {
        setIsAuthenticated(false);
        setLoading(false);
      }
    };

    window.addEventListener('storage', checkAuth);
    checkAuth();

    return () => window.removeEventListener('storage', checkAuth);
    // eslint-disable-next-line
  }, []);

  const addAccount = async (accountData: Partial<AccountType>) => {
    setLoading(true);
    setError(null);
    try {
      const accessToken = localStorage.getItem('sf_access_token');
      const instanceUrl = localStorage.getItem('sf_instance_url');
      const supabaseUserId = (await supabase.auth.getUser()).data.user?.id;

      if (!accessToken || !instanceUrl || !supabaseUserId) {
        throw new Error('Not authenticated with Salesforce');
      }

      const { data: mapping, error: mappingError } = await supabase
        .from('user_mapping')
        .select('salesforce_user_id')
        .eq('supabase_user_id', supabaseUserId)
        .maybeSingle();

      if (mappingError) throw new Error(`Mapping error: ${mappingError.message}`);
      if (!mapping?.salesforce_user_id) throw new Error('User mapping not found');

      const headers = {
        'Authorization': `Bearer ${accessToken}`,
        'sf-instance-url': instanceUrl,
        'sf-user-id': mapping.salesforce_user_id,
        'Content-Type': 'application/json',
      };

      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/salesforce-token/accounts`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify({
            Name: accountData.name,
            Industry: accountData.industry,
            Website: accountData.website,
            Phone: accountData.phone,
            Type: accountData.type,
            BillingCity: accountData.city,
            BillingCountry: accountData.country,
          }),
        }
      );

      const result = await res.json();
      if (!res.ok) throw new Error(result.error || 'Failed to create account');

      await fetchSalesforceData();
    } catch (err: any) {
      setError(err.message || 'Failed to add account');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const value = {
    ...data,
    activities,
    calls,
    emails,
    tasks,
    events,
    loading,
    error,
    isAuthenticated,
    refreshData: fetchSalesforceData,
    getObjectById,
    addLead,
    addAccount,
  };

  return <SalesforceContext.Provider value={value}>{children}</SalesforceContext.Provider>;
};
