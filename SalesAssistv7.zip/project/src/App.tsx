import React, { Suspense, lazy, useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/layout/Layout';
import LoadingSpinner from './components/ui/LoadingSpinner';
import { SalesforceProvider } from './context/SalesforceContext';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/auth/ProtectedRoute';
import SlackIntegration from './pages/SlackIntegration';

// Lazy loaded pages
const LandingPage = lazy(() => import('./pages/LandingPage'));
const AuthPage = lazy(() => import('./pages/auth/AuthPage'));
const RegisterPage = lazy(() => import('./pages/RegisterPage'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const SearchResults = lazy(() => import('./pages/SearchResults'));
const Leads = lazy(() => import('./pages/Leads'));
const LeadDetail = lazy(() => import('./pages/LeadDetail'));
const Accounts = lazy(() => import('./pages/Accounts'));
const AccountDetail = lazy(() => import('./pages/AccountDetail'));
const Contacts = lazy(() => import('./pages/Contacts'));
const ContactDetail = lazy(() => import('./pages/ContactDetail'));
const Opportunities = lazy(() => import('./pages/Opportunities'));
const OpportunityDetail = lazy(() => import('./pages/OpportunityDetail'));
const OpportunityPipeline = lazy(() => import('./pages/OpportunityPipeline'));
const EmailComposer = lazy(() => import('./pages/EmailComposer'));
const UserManagement = lazy(() => import('./pages/admin/UserManagement'));
const Permissions = lazy(() => import('./pages/admin/Permissions'));
const Integrations = lazy(() => import('./pages/admin/Integrations'));
const AgentDashboard = lazy(() => import('./pages/AgentDashboard'));
const ApiGenerate = lazy(() => import('./api/apigenerate'));
const CallbackPage = lazy(() => import('./pages/auth/callback')); // For Google OAuth redirect

function App() {
  // Theme state: 'light', 'dark', or 'system'
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>(() => {
    return (localStorage.getItem('theme') as 'light' | 'dark' | 'system') || 'system';
  });

  // Effect to toggle the 'dark' class on <html>
  useEffect(() => {
    const root = window.document.documentElement;
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (theme === 'dark' || (theme === 'system' && systemPrefersDark)) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  return (
    // This wrapper ensures background and text color respond to theme
    <div className="bg-white dark:bg-gray-900 min-h-screen text-black dark:text-white transition-colors duration-300">
      <AuthProvider>
        <SalesforceProvider>
          <Suspense fallback={<LoadingSpinner />}>
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<LandingPage />} />
              <Route path="/auth" element={<AuthPage />} />
              <Route path="/signup" element={<RegisterPage />} />
              <Route path="/auth/callback" element={<CallbackPage />} />

              {/* Protected routes */}
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    {/* Pass theme and setTheme to Layout/Header for toggle UI */}
                    <Layout theme={theme} setTheme={setTheme}>
                      <Dashboard />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/search"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <SearchResults />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/ai-agents"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <AgentDashboard />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
  path="/admin/api-keys"
  element={
    <ProtectedRoute>
      <Layout theme={theme} setTheme={setTheme}>
        <ApiGenerate />
      </Layout>
    </ProtectedRoute>
  }
/>

              <Route
                path="/leads"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <Leads />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/leads/:id"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <LeadDetail />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/accounts"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <Accounts />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/accounts/:id"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <AccountDetail />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/contacts"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <Contacts />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/contacts/:id"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <ContactDetail />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/opportunities"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <Opportunities />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/opportunities/:id"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <OpportunityDetail />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/pipeline"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <OpportunityPipeline />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/email-composer"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <EmailComposer />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/users"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <UserManagement />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/permissions"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <Permissions />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/slack"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <SlackIntegration />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/integrations"
                element={
                  <ProtectedRoute>
                    <Layout theme={theme} setTheme={setTheme}>
                      <Integrations />
                    </Layout>
                  </ProtectedRoute>
                }
              />

              {/* Catch all: redirect to landing page */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Suspense>
        </SalesforceProvider>
      </AuthProvider>
    </div>
  );
}

export default App;
