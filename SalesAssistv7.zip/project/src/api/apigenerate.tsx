import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { IconKey, IconTrash } from '@tabler/icons-react';

interface ApiKey {
  id: string;
  client_id: string;
  name?: string;
  created_at: string;
  revoked: boolean;
  expires_at?: string | null;
}

interface NewKey {
  client_id: string;
  client_secret: string;
}

const ApiKeyManager: React.FC = () => {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [newKey, setNewKey] = useState<NewKey | null>(null);
  const [loading, setLoading] = useState(false);

  // Fetch API keys on mount
  useEffect(() => {
    fetchApiKeys();
  }, []);

  const fetchApiKeys = async () => {
    setLoading(true);
    try {
      const res = await axios.get('/api/api-keys');
      setApiKeys(res.data.data || []);
    } catch (err) {
      alert('Failed to load API keys');
    }
    setLoading(false);
  };

  const generateKey = async () => {
    setLoading(true);
    try {
      const res = await axios.post<NewKey>('/api/api-keys', { name: '' });
      setNewKey(res.data);
      await fetchApiKeys();
    } catch (err) {
      alert('Failed to generate API key');
    }
    setLoading(false);
  };

  const revokeKey = async (id: string) => {
    if (!window.confirm('Are you sure you want to revoke this key?')) return;
    setLoading(true);
    try {
      await axios.delete(`/api/api-keys/${id}`);
      await fetchApiKeys();
    } catch (err) {
      alert('Failed to revoke API key');
    }
    setLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4 flex items-center">
        <IconKey className="mr-2" /> API Keys
      </h2>
      <button
        className="mb-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={generateKey}
        disabled={loading}
      >
        Generate New API Key
      </button>

      {newKey && (
        <div className="mb-6 p-4 bg-yellow-50 border border-yellow-300 rounded">
          <p className="mb-2 font-semibold text-yellow-800">New API Key generated!</p>
          <p>
            <strong>Client ID:</strong> <span className="font-mono">{newKey.client_id}</span>
          </p>
          <p>
            <strong>Client Secret:</strong> <span className="font-mono">{newKey.client_secret}</span>
          </p>
          <p className="text-red-500 text-sm mt-2">
            Copy the Client Secret now. You will not be able to see it again!
          </p>
        </div>
      )}

      <h3 className="text-lg font-semibold mb-2">Your API Keys</h3>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <table className="w-full text-left border">
          <thead>
            <tr>
              <th className="px-2 py-1 border-b">Client ID</th>
              <th className="px-2 py-1 border-b">Created</th>
              <th className="px-2 py-1 border-b">Status</th>
              <th className="px-2 py-1 border-b">Actions</th>
            </tr>
          </thead>
          <tbody>
            {apiKeys.length === 0 ? (
              <tr>
                <td colSpan={4} className="text-center py-4">No API keys found.</td>
              </tr>
            ) : (
              apiKeys.map((key) => (
                <tr key={key.id}>
                  <td className="px-2 py-1 font-mono">{key.client_id}</td>
                  <td className="px-2 py-1">{new Date(key.created_at).toLocaleString()}</td>
                  <td className="px-2 py-1">
                    {key.revoked ? (
                      <span className="text-red-600">Revoked</span>
                    ) : (
                      <span className="text-green-600">Active</span>
                    )}
                  </td>
                  <td className="px-2 py-1">
                    {!key.revoked && (
                      <button
                        className="text-red-600 hover:text-red-800"
                        onClick={() => revokeKey(key.id)}
                        title="Revoke Key"
                      >
                        <IconTrash size={18} />
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ApiKeyManager;
