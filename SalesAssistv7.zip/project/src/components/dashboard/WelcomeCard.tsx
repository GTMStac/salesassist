import React from 'react';
import { Sparkles } from 'lucide-react';

const WelcomeCard = ({ displayName }) => (
  <div className="rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 p-6 shadow-lg text-white">
    <div className="flex items-center gap-4">
      <div className="h-16 w-16 rounded-full bg-white/20 flex items-center justify-center">
        <Sparkles className="h-8 w-8 text-white" />
      </div>
      <div>
        <h1 className="text-2xl font-bold">Welcome back, {displayName}!</h1>
        <p className="opacity-90">Here’s what’s happening with your business today</p>
      </div>
    </div>
  </div>
);

export default WelcomeCard;
