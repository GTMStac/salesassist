import { Link } from 'react-router-dom';
import { Sparkles } from 'lucide-react';

const HighScoringLeadsCard = ({ leads }) => (
  <div className="rounded-xl border border-indigo-100 bg-white/70 backdrop-blur-md p-5 shadow-lg hover:shadow-xl transition-all">
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-lg font-semibold text-indigo-900">High-Scoring Leads</h2>
      <Sparkles className="h-6 w-6 text-indigo-400 animate-pulse" />
    </div>
    <div className="space-y-4">
      {leads.length > 0 ? (
        leads.slice(0, 4).map(lead => (
          <div
            key={lead.id}
            className="flex items-center justify-between p-3 rounded-lg bg-white/50 backdrop-blur-sm border border-indigo-50 hover:bg-indigo-50/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-indigo-200 to-blue-200 flex items-center justify-center">
                <span className="text-indigo-700 font-medium">
                  {lead.firstName?.[0]}{lead.lastName?.[0]}
                </span>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-base text-slate-900">
                    {lead.firstName} {lead.lastName}
                  </span>
                  {lead.salesforceUrl && (
                    <a
                      href={lead.salesforceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      title="View in Salesforce"
                      className="inline-flex items-center"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 32 32"
                        width="20"
                        height="20"
                        className="ml-1"
                      >
                        <circle cx="16" cy="16" r="16" fill="#0074D9" />
                        <text
                          x="16"
                          y="22"
                          textAnchor="middle"
                          fontSize="15"
                          fill="#fff"
                          fontFamily="Arial, sans-serif"
                        >
                          SF
                        </text>
                      </svg>
                    </a>
                  )}
                </div>
                <p className="text-sm text-slate-600">{lead.company}</p>
                <p className="text-sm text-slate-600">{lead.phone}</p>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <span className="inline-flex rounded-full px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800">
                Score: {lead.leadScore}
              </span>
              <div className="mt-2 w-24 h-2 bg-blue-100 rounded-full">
                <div
                  className="h-2 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600"
                  style={{ width: `${lead.leadScore}%` }}
                />
              </div>
            </div>
          </div>
        ))
      ) : (
        <div className="p-4 text-slate-600 text-sm">No high-scoring leads found.</div>
      )}
    </div>
    <div className="mt-4 border-t border-indigo-100 pt-3">
      <Link
        to="/leads"
        className="flex w-full items-center justify-center rounded-md bg-indigo-50 py-2 text-sm font-medium text-indigo-700 hover:bg-indigo-100 transition-colors"
      >
        View All Leads
      </Link>
    </div>
  </div>
);

export default HighScoringLeadsCard;
