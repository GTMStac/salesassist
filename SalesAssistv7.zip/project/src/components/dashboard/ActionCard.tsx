import { Link } from 'react-router-dom';
import { Sparkles } from 'lucide-react';

const ActionCard = ({ icon: Icon, title, steps, to, color, hoverColor }) => (
  <Link
    to={to}
    className={`relative group rounded-xl p-5 backdrop-blur-sm ${color} hover:${hoverColor} text-white shadow-lg hover:shadow-xl transition-all hover:scale-[1.02] overflow-hidden`}
  >
    <div className="flex flex-col items-center justify-between h-full">
      <div className="flex flex-col items-center gap-3">
        <div className="p-3 rounded-full bg-white/20 backdrop-blur-sm">
          <Icon size={24} />
        </div>
        <span className="font-semibold">{title}</span>
      </div>
      {steps && (
        <div className="flex flex-wrap justify-center gap-2 mt-3">
          {steps.map((step, i) => (
            <span
              key={i}
              className="px-2 py-1 text-xs rounded-full bg-white/20 backdrop-blur-sm"
            >
              {step}
            </span>
          ))}
        </div>
      )}
    </div>
    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
      <Sparkles className="absolute top-2 right-2 h-6 w-6 text-white/40" />
    </div>
  </Link>
);

export default ActionCard;

// Usage:
// <ActionCard
//   icon={Users}
//   title="Add Lead"
//   to="/leads/new"
//   color="bg-gradient-to-br from-blue-600 to-blue-800"
//   hoverColor="bg-gradient-to-br from-blue-700 to-blue-900"
//   steps={['New', 'Import', 'Assign']}
// />
