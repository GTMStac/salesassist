import React from 'react';
import { Sparkles } from 'lucide-react';

const PipelineHealthCard = ({ opportunityStages, opportunities, totalRevenue }) => {
  return (
    <div className="rounded-xl bg-white/70 backdrop-blur-md border border-indigo-100 p-6 shadow-lg hover:shadow-xl transition-all">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="h-6 w-6 text-indigo-400 animate-pulse" />
            <h2 className="text-lg font-semibold text-indigo-900">Pipeline Health</h2>
          </div>
          <div className="flex flex-wrap gap-4">
            {opportunityStages.map((stage) => (
              <div key={stage} className="flex flex-col items-center">
                <div className="rounded-full bg-gradient-to-br from-indigo-100 to-blue-100 h-14 w-14 flex items-center justify-center shadow">
                  <span className="font-bold text-indigo-700">
                    ${(
                      opportunities
                        .filter(opp => opp.stage === stage)
                        .reduce((sum, opp) => sum + (opp.amount || 0), 0) / 1000
                    ).toFixed(0)}k
                  </span>
                </div>
                <span className="mt-2 text-xs text-slate-600">{stage}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="flex-1">
          <h2 className="text-lg font-semibold text-indigo-900 mb-2">Goal Progress</h2>
          <p className="text-sm text-slate-600 mb-1">Q2 Revenue Goal: $2,000,000</p>
          <div className="w-full bg-blue-100 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-blue-600 to-indigo-600 h-3 rounded-full"
              style={{ width: `${Math.min((totalRevenue / 2000000) * 100, 100)}%` }}
            >
              <span className="text-xs text-white px-2">
                {Math.round((totalRevenue / 2000000) * 100)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PipelineHealthCard;
