import React, { useState, useRef, useEffect } from 'react';
import { Bell, HelpCircle, User, LogOut, Settings, Camera } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from "../../supabaseClient";
import { useAuth } from '../../context/AuthContext';

const Header: React.FC = ({ children }) => {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: 1, title: 'New lead assigned', message: 'John Doe has been assigned to you', time: '2 min ago', read: false },
    { id: 2, title: 'Meeting reminder', message: 'Team standup in 30 minutes', time: '28 min ago', read: false },
    { id: 3, title: 'Deal closed', message: 'Acme Corp deal worth $50k closed', time: '1 hour ago', read: true },
  ]);

  const navigate = useNavigate();
  const { user } = useAuth();
  const userMenuRef = useRef<HTMLDivElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);
  const settingsRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) setShowUserMenu(false);
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) setShowNotifications(false);
      if (settingsRef.current && !settingsRef.current.contains(event.target as Node)) setShowSettings(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      navigate('/auth');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user?.id}-${Math.random()}.${fileExt}`;
      const filePath = `avatars/${fileName}`;
      const { error: uploadError } = await supabase.storage.from('avatars').upload(filePath, file);
      if (uploadError) throw uploadError;
      const { data } = supabase.storage.from('avatars').getPublicUrl(filePath);
      const { error: updateError } = await supabase.auth.updateUser({ data: { avatar_url: data.publicUrl } });
      if (updateError) throw updateError;
      alert('Profile photo updated successfully!');
    } catch (error) {
      console.error('Error uploading photo:', error);
      alert('Error uploading photo. Please try again.');
    }
  };

  const markNotificationAsRead = (id: number) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  // User info
  const fullName = user?.user_metadata?.full_name || user?.user_metadata?.name || '';
  let firstName = user?.user_metadata?.first_name || '';
  let lastName = user?.user_metadata?.last_name || '';
  if ((!firstName || !lastName) && fullName) {
    const parts = fullName.split(' ');
    firstName = parts[0];
    lastName = parts.slice(1).join(' ');
  }
  const email = user?.email || '';
  const avatarUrl = user?.user_metadata?.avatar_url;
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="relative z-50 flex h-16 items-center justify-between border-b bg-white px-4 shadow-sm md:px-6">
      <div className="flex items-center space-x-2">
        {children}
      </div>
      <div className="flex items-center space-x-4">
        {/* Notifications */}
        <div className="relative" ref={notificationsRef}>
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative text-slate-600 hover:text-primary-600 transition-colors"
            aria-label="Notifications"
          >
            <Bell className="h-5 w-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 rounded-md border border-slate-200 bg-white shadow-lg z-50">
              <div className="p-3 border-b">
                <h3 className="font-semibold text-slate-900">Notifications</h3>
              </div>
              <div className="max-h-96 overflow-y-auto">
                {notifications.map(notification => (
                  <div
                    key={notification.id}
                    onClick={() => markNotificationAsRead(notification.id)}
                    className={`p-3 border-b hover:bg-slate-50 cursor-pointer ${
                      !notification.read ? 'bg-blue-50' : ''
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className="font-medium text-sm text-slate-900">{notification.title}</p>
                        <p className="text-xs text-slate-600 mt-1">{notification.message}</p>
                      </div>
                      <span className="text-xs text-slate-500">{notification.time}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-3 text-center border-t">
                <button className="text-sm text-blue-600 hover:underline">
                  View all notifications
                </button>
              </div>
            </div>
          )}
        </div>
        {/* Settings */}
        <div className="relative" ref={settingsRef}>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="text-slate-600 hover:text-primary-600 transition-colors"
            aria-label="Settings"
          >
            <Settings className="h-5 w-5" />
          </button>
          {showSettings && (
            <div className="absolute right-0 mt-2 w-56 rounded-md border border-slate-200 bg-white shadow-lg z-50">
              <div className="p-2">
                <button
                  onClick={() => navigate('/settings/general')}
                  className="flex w-full items-center rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <Settings className="mr-2 h-4 w-4" />
                  General Settings
                </button>
                <button
                  onClick={() => navigate('/settings/notifications')}
                  className="flex w-full items-center rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <Bell className="mr-2 h-4 w-4" />
                  Notification Settings
                </button>
                <button
                  onClick={() => navigate('/settings/privacy')}
                  className="flex w-full items-center rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <HelpCircle className="mr-2 h-4 w-4" />
                  Privacy & Security
                </button>
              </div>
            </div>
          )}
        </div>
        {/* User Menu */}
        <div className="relative" ref={userMenuRef}>
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center space-x-1 rounded-full"
            aria-haspopup="true"
            aria-expanded={showUserMenu}
          >
            <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 overflow-hidden">
              {avatarUrl ? (
                <img src={avatarUrl} alt="Profile" className="h-full w-full object-cover" />
              ) : (
                <User className="h-5 w-5" />
              )}
            </div>
            <span className="hidden text-sm font-medium md:block text-slate-900">
              {firstName} {lastName}
            </span>
          </button>
          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-56 rounded-md border border-slate-200 bg-white shadow-lg z-50">
              <div className="p-3 border-b">
                <div className="flex items-center space-x-3">
                  <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 overflow-hidden">
                    {avatarUrl ? (
                      <img src={avatarUrl} alt="Profile" className="h-full w-full object-cover" />
                    ) : (
                      <User className="h-6 w-6" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-slate-900">{firstName} {lastName}</p>
                    <p className="text-xs text-slate-500">{email}</p>
                  </div>
                </div>
              </div>
              <div className="p-2">
                <button
                  onClick={() => navigate('/profile')}
                  className="flex w-full items-center rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </button>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex w-full items-center rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <Camera className="mr-2 h-4 w-4" />
                  Change Photo
                </button>
                <button
                  onClick={handleSignOut}
                  className="flex w-full items-center rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* Hidden file input for photo upload */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handlePhotoUpload}
        className="hidden"
      />
    </header>
  );
};

export default Header;
