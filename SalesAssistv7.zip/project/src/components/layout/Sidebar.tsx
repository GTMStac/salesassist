import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  IconLayoutDashboard,
  IconUsersGroup,
  IconBriefcase,
  IconPhoneCall,
  IconTrendingUp,
  IconMail,
  IconChartBar,
  IconCalendarEvent,
  IconSettings,
  IconX,
  IconShield,
  IconUserPlus,
  IconPlug,
  IconGitBranch,
  IconRobot,
  IconCpu,
  IconKey,
  IconZoomFilled
} from '@tabler/icons-react';

interface SidebarProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ open, setOpen }) => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;

  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: IconLayoutDashboard },
    { name: 'Leads', href: '/leads', icon: IconUsersGroup },
    { name: 'Accounts', href: '/accounts', icon: IconBriefcase },
    { name: 'Contacts', href: '/contacts', icon: IconPhoneCall },
    { name: 'Opportunities', href: '/opportunities', icon: IconTrendingUp },
    { name: 'Pipeline', href: '/pipeline', icon: IconGitBranch },
    { name: 'Email Composer', href: '/email-composer', icon: IconMail },
    { name: 'Analytics', href: '/analytics', icon: IconChartBar },
    { name: 'Calendar', href: '/calendar', icon: IconCalendarEvent },
  ];

  const adminNavigation = [
    { name: 'User Management', href: '/admin/users', icon: IconUserPlus },
    { name: 'Permissions', href: '/admin/permissions', icon: IconShield },
    { name: 'Integrations', href: '/admin/integrations', icon: IconPlug },
    { name: 'Slack', href: '/admin/slack', icon: IconPlug },
    { name: 'API', href: '/admin/api-keys', icon: IconKey },
  ];

  const aiNavigation = [
    { name: 'AI Agents', href: '/ai-agents', icon: IconCpu }
  ];

  return (
    <div
      className={`fixed inset-y-0 left-0 z-20 w-64 transform bg-white shadow-lg transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:inset-auto lg:h-screen ${
        open ? 'translate-x-0' : '-translate-x-full'
      }`}
    >
      {/* Gtm Stac blue card at the top */}
      <div className="flex h-24 items-center justify-between px-4">
        <div className="w-full">
          <div className="rounded-xl bg-[#1673FF] px-4 py-3 flex flex-col items-start shadow-lg">
            <div className="flex items-center mb-1">
              <span className="mr-2">
                <IconBriefcase className="h-6 w-6 text-white" />
              </span>
              <span className="text-lg font-semibold text-white">Gtm Stac</span>
            </div>
            <span className="text-sm text-blue-100">Your Sales AI Assistant</span>
          </div>
        </div>
        <button
          type="button"
          className="rounded-md p-2 text-blue-400 hover:bg-blue-100 lg:hidden ml-2"
          onClick={() => setOpen(false)}
        >
          <IconX className="h-5 w-5" />
        </button>
      </div>
      <nav className="flex h-[calc(100%-4rem)] flex-col justify-between">
        <div className="flex-1 space-y-1 px-2 py-4">
          {navigation.map((item) => {
            const active = isActive(item.href);
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`group flex items-center rounded-md px-3 py-2 text-sm font-medium transition-all
                  ${active
                    ? 'bg-blue-50 shadow-lg ring-2 ring-blue-300 text-black'
                    : 'text-black hover:bg-blue-100'
                  }`}
                onClick={() => setOpen(false)}
              >
                <item.icon className={`mr-3 h-5 w-5 flex-shrink-0 ${active ? 'text-blue-600' : 'text-blue-300 group-hover:text-blue-600'}`} />
                {item.name}
              </Link>
            );
          })}
          <div className="my-4 border-t border-blue-100"></div>
          <div className="px-3 py-2">
            <h3 className="text-xs font-semibold uppercase text-blue-400">Administration</h3>
          </div>
          {adminNavigation.map((item) => {
            const active = isActive(item.href);
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`group flex items-center rounded-md px-3 py-2 text-sm font-medium transition-all
                  ${active
                    ? 'bg-blue-50 shadow-lg ring-2 ring-blue-300 text-black'
                    : 'text-black hover:bg-blue-100'
                  }`}
                onClick={() => setOpen(false)}
              >
                <item.icon className={`mr-3 h-5 w-5 flex-shrink-0 ${active ? 'text-blue-600' : 'text-blue-300 group-hover:text-blue-600'}`} />
                {item.name}
              </Link>
            );
          })}
          {/* AI Navigation Section */}
          <div className="my-4 border-t border-blue-100"></div>
          <div className="px-3 py-2">
            <h3 className="text-xs font-semibold uppercase text-blue-400">AI</h3>
          </div>
          {aiNavigation.map((item) => {
            const active = isActive(item.href);
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`group flex items-center rounded-md px-3 py-2 text-sm font-medium transition-all
                  ${active
                    ? 'bg-blue-50 shadow-lg ring-2 ring-blue-300 text-black'
                    : 'text-black hover:bg-blue-100'
                  }`}
                onClick={() => setOpen(false)}
              >
                <item.icon className={`mr-3 h-5 w-5 flex-shrink-0 ${active ? 'text-blue-600' : 'text-blue-300 group-hover:text-blue-600'}`} />
                {item.name}
              </Link>
            );
          })}
        </div>
        <div className="border-t border-blue-100 p-4">
          <Link
            to="/settings"
            className="flex items-center rounded-md px-3 py-2 text-sm font-medium text-black hover:bg-blue-100 transition-colors"
          >
            <IconSettings className="mr-3 h-5 w-5 text-blue-500" />
            Settings
          </Link>
          <div className="mt-4 rounded-md bg-blue-50 p-3">
            <p className="text-xs font-medium text-blue-800">Need help?</p>
            <p className="text-xs text-blue-700">
              Check out our documentation or contact support.
            </p>
            <button className="mt-2 text-xs font-medium text-blue-700 hover:text-blue-900 hover:underline">
              View support options
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Sidebar;
