import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, ShieldCheck, Info } from 'lucide-react';

const searchSources = [
  { id: "all", label: "All Sources" },
  { id: "salesforce", label: "Salesforce Only" },
  { id: "linkedin", label: "LinkedIn" },
  { id: "zoominfo", label: "ZoomInfo" },
  { id: "web", label: "Web Search" },
];

const SearchBar = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeSource, setActiveSource] = useState('all');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;
    navigate(`/search?q=${encodeURIComponent(searchTerm.trim())}`);
  };

  return (
    <div className="bg-white rounded-xl shadow border border-gray-200 p-8 w-full">
      {/* AI Sales Intelligence Header */}
      <div className="flex items-center gap-2 mb-1">
        <ShieldCheck className="h-6 w-6 text-blue-600" />
        <span className="text-2xl font-semibold text-gray-900">
          AI Sales Intelligence
        </span>
      </div>
      <p className="text-gray-500 text-base mb-4">
        Search for prospects or companies to get AI-powered insights and sales recommendations.
      </p>

      {/* Search Bar */}
      <form onSubmit={handleSearch} className="w-full mb-2">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="search"
            placeholder="Search for a prospect or company..."
            className="w-full h-12 rounded-md border border-gray-300 bg-white pl-10 pr-24 text-base outline-none focus:ring-2 focus:ring-blue-200 transition"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            autoFocus
          />
          <button
            type="submit"
            className="absolute right-4 top-1/2 -translate-y-1/2 text-blue-600 font-medium hover:underline"
          >
            Search
          </button>
        </div>
        <div className="flex items-center mt-2 text-xs text-gray-400">
          <Info className="inline h-4 w-4 mr-1" />
          Try searching for a prospect name, company, industry, or specific need.
          <span className="ml-1 text-blue-500 font-semibold">Powered by Gtm Stac</span>
        </div>
      </form>

      {/* Tabs */}
      <div className="flex gap-2 w-full mt-4">
        {searchSources.map((source) => (
          <button
            key={source.id}
            type="button"
            onClick={() => setActiveSource(source.id)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium border transition
              ${activeSource === source.id
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-100'}`}
          >
            {source.label}
          </button>
        ))}
      </div>

      {/* Info Prompt */}
      {!searchTerm && (
        <div className="w-full bg-gray-100 flex flex-col items-center justify-center py-10 mt-6 rounded-lg">
          <Info className="h-10 w-10 text-gray-400 mb-2" />
          <p className="font-medium text-gray-700 text-center">
            Enter a prospect or company name above to get started.
          </p>
          <p className="text-sm text-gray-400 text-center max-w-lg">
            SalesAI Navigator will fetch information from Salesforce and public sources.
          </p>
        </div>
      )}
    </div>
  );
};

export default SearchBar;
