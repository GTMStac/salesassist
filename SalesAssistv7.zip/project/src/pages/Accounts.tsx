import React, { useState } from 'react';
import { useSalesforce } from '../context/SalesforceContext';
import ObjectList from '../components/objects/ObjectList';
import { Globe, MapPin, Building, Phone, Users } from 'lucide-react';
import { Link } from 'react-router-dom';


const accountTypes = [
  { value: 'Prospect', label: 'Prospect' },
  { value: 'Open Opportunity', label: 'Open Opportunity' },
  { value: 'Customer', label: 'Customer' },
];


const Accounts = () => {
  const { accounts, loading } = useSalesforce();

    const [showForm, setShowForm] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    industry: '',
    website: '',
    phone: '',
    type: '',
    city: '',
    country: '',
  });

  const columns = [
    {
      key: 'name',
      title: 'Account Name',
      render: (account: any) => (
        <Link
          to={`/accounts/${account.id}`}
          className="font-medium text-slate-900 hover:text-blue-600 transition-colors"
        >
          {account.name}
        </Link>
      ),
    },
    {
      key: 'industry',
      title: 'Industry',
      render: (account: any) => (
        <div className="flex items-center">
          <Building className="mr-1 h-4 w-4 text-slate-400" />
          <span>{account.industry}</span>
        </div>
      ),
    },
    {
      key: 'website',
      title: 'Website',
      render: (account: any) => (
        <div className="flex items-center">
          <Globe className="mr-1 h-4 w-4 text-slate-400" />
          <span>{account.website}</span>
        </div>
      ),
    },
    {
      key: 'phone',
      title: 'Phone',
      render: (account: any) => (
        <div className="flex items-center">
          <Phone className="mr-1 h-4 w-4 text-slate-400" />
          <span>{account.phone}</span>
        </div>
      ),
    },
    {
      key: 'type',
      title: 'Type',
      render: (account: any) => {
        let bgColor = 'bg-slate-100 text-slate-800';
        if (account.type === 'Customer') bgColor = 'bg-green-100 text-green-800';
        if (account.type === 'Prospect') bgColor = 'bg-blue-100 text-blue-800';
        return (
          <span className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${bgColor}`}>
            {account.type}
          </span>
        );
      },
    },
    {
      key: 'address',
      title: 'Address',
      render: (account: any) => (
        <div className="flex items-center">
          <MapPin className="mr-1 h-4 w-4 text-slate-400" />
          <span>{[account.city, account.country].filter(Boolean).join(', ')}</span>
        </div>
      ),
    },
  ];
const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(f => ({ ...f, [name]: value }));
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormLoading(true);
    setFormError('');
    try {
      if (!formData.name || !formData.type) {
        setFormError('Account Name and Type are required.');
        setFormLoading(false);
        return;
      }
      await addAccount(formData);
      setShowForm(false);
      setFormData({
        name: '',
        industry: '',
        website: '',
        phone: '',
        type: '',
        city: '',
        country: '',
      });
    } catch (err: any) {
      setFormError(err.message || 'Failed to add account');
    } finally {
      setFormLoading(false);
    }
  };
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50/50 to-indigo-50/50 p-4 md:p-6 font-sans">
      {/* Modal Form */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-lg relative">
            <button
              className="absolute top-2 right-2 text-gray-400 hover:text-gray-700 text-2xl"
              onClick={() => setShowForm(false)}
              aria-label="Close"
            >
              ×
            </button>
            <h2 className="text-xl font-bold mb-4">Add New Account</h2>
            {formError && <div className="mb-2 text-red-600">{formError}</div>}
            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="block font-medium mb-1">Account Name<span className="text-red-500">*</span></label>
                <input
                  type="text"
                  name="name"
                  className="w-full border rounded px-3 py-2"
                  required
                  value={formData.name}
                  onChange={handleFormChange}
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Industry</label>
                <input
                  type="text"
                  name="industry"
                  className="w-full border rounded px-3 py-2"
                  value={formData.industry}
                  onChange={handleFormChange}
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Website</label>
                <input
                  type="url"
                  name="website"
                  className="w-full border rounded px-3 py-2"
                  value={formData.website}
                  onChange={handleFormChange}
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Phone</label>
                <input
                  type="tel"
                  name="phone"
                  className="w-full border rounded px-3 py-2"
                  value={formData.phone}
                  onChange={handleFormChange}
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Type<span className="text-red-500">*</span></label>
                <select
                  name="type"
                  className="w-full border rounded px-3 py-2"
                  required
                  value={formData.type}
                  onChange={handleFormChange}
                >
                  <option value="">Select type</option>
                  {accountTypes.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="block font-medium mb-1">City</label>
                  <input
                    type="text"
                    name="city"
                    className="w-full border rounded px-3 py-2"
                    value={formData.city}
                    onChange={handleFormChange}
                  />
                </div>
                <div className="flex-1">
                  <label className="block font-medium mb-1">Country</label>
                  <input
                    type="text"
                    name="country"
                    className="w-full border rounded px-3 py-2"
                    value={formData.country}
                    onChange={handleFormChange}
                  />
                </div>
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded px-4 py-2 mt-2"
                disabled={formLoading}
              >
                {formLoading ? 'Saving...' : 'Save Account'}
              </button>
            </form>
          </div>
        </div>
      )}
      {/* Hero/Banner Section */}
      <div className="flex items-center justify-between p-6 rounded-xl bg-white/70 backdrop-blur-sm shadow-lg border border-indigo-100 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Accounts</h1>
          <p className="text-slate-500 mt-1">Manage your customer and prospect accounts</p>
        </div>
        <button className="inline-flex items-center rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 px-6 py-3 text-sm font-medium text-white hover:shadow-lg hover:from-blue-700 hover:to-indigo-700 transition-all" onClick={() => setShowForm(true)}>
          <Building className="mr-2 h-4 w-4" />
          Add New Account
        </button>
      </div>

      {/* Table Section */}
      <div className="rounded-xl bg-white/70 backdrop-blur-sm shadow-lg border border-indigo-100 overflow-hidden">
        <ObjectList
          title="Accounts"
          data={accounts}
          columns={columns}
          basePath="/accounts"
          isLoading={loading}
          className="rounded-xl bg-white/70 backdrop-blur-sm shadow-lg border border-indigo-100 overflow-hidden"
          rowClassName="hover:bg-indigo-50/50 transition-colors group"
        />
      </div>
    </div>
  );
};

export default Accounts;
