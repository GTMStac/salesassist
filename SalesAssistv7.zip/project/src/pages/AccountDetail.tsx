import React, { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useSalesforce } from "../context/SalesforceContext";
import {
  Building, Globe, MapPin, Phone, ArrowLeft, ExternalLink, Activity, StickyNote,
  MailOpen, PhoneCall, CheckSquare, Calendar, Users, Star, Bell, FileText
} from "lucide-react";

type ActivityType = "Activity" | "Notes" | "Emails" | "Calls" | "Task" | "Meetings";

const activityTypes = [
  { icon: Activity, label: "Activity" },
  { icon: StickyNote, label: "Notes" },
  { icon: MailOpen, label: "Emails" },
  { icon: PhoneCall, label: "Calls" },
  { icon: CheckSquare, label: "Task" },
  { icon: Calendar, label: "Meetings" },
];

const AccountDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { getObjectById } = useSalesforce();
  const account = getObjectById("accounts", id);

  // Tab states
  const [leftTab, setLeftTab] = useState<"accountInfo" | "addressInfo">("accountInfo");
  const [mainTab, setMainTab] = useState<"overview" | "activities">("activities");
  const [activityType, setActivityType] = useState<ActivityType>("Activity");

  if (!account) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500">
        Account not found.
      </div>
    );
  }

  // Example qualification score
  const qualification = {
    label: "Hot",
    color: "bg-green-100 text-green-700",
    score: 87,
    explanation: "High engagement and recent activity",
  };

  // Example files
  const files = [
    { name: "Proposal.pdf", url: "#", uploaded: "2025-06-01" },
    { name: "NDA.docx", url: "#", uploaded: "2025-05-22" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50/50 to-indigo-50/50 p-2 sm:p-4 md:p-6 font-sans">
      {/* Sticky Action Bar */}
      <div className="sticky top-0 z-20 bg-white/90 backdrop-blur flex flex-col sm:flex-row flex-wrap items-center justify-between px-8 py-4 border-b shadow-sm">
        <div className="flex items-center gap-4">
          <div className="bg-gradient-to-tr from-blue-500 to-indigo-500 rounded-full w-14 h-14 flex items-center justify-center text-white text-2xl font-bold shadow-md">
            <Building className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg sm:text-xl md:text-2xl font-bold text-gray-900">
                {account.name}
              </span>
              <span className={`ml-2 px-2 py-0.5 rounded-full text-xs font-semibold ${qualification.color}`}>
                <Star className="h-3 w-3 sm:h-4 sm:w-4 inline mr-1" /> {qualification.label} ({qualification.score})
              </span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Phone className="h-4 w-4" />
              <span>{account.phone}</span>
              <Globe className="h-4 w-4 ml-4" />
              <span>{account.website}</span>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <a
            href={`https://login.salesforce.com/${account.id}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-md bg-gradient-to-br from-blue-600 to-indigo-600 text-white font-semibold px-4 py-2 text-sm hover:shadow-lg transition"
          >
            <img
              src="https://cdn.worldvectorlogo.com/logos/salesforce-2.svg"
              alt="Salesforce"
              className="h-5 w-5"
            />
            View in Salesforce
            <ExternalLink className="h-4 w-4" />
          </a>
          <button className="rounded-md bg-yellow-50 px-4 py-2 text-sm font-medium text-yellow-700 hover:bg-yellow-100 transition flex items-center gap-1">
            <Bell className="h-4 w-4" /> Reminder
          </button>
          {["Notes", "Email", "Call", "Task"].map(action => (
            <button
              key={action}
              className="rounded-md bg-gray-100 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200 transition"
            >
              {action}
            </button>
          ))}
        </div>
      </div>

      {/* Responsive 3-column layout */}
      <div className="w-full max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 px-4 py-8">
        {/* Left Sidebar */}
        <aside className="lg:col-span-3 flex flex-col gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-6">
            <Link
              to="/accounts"
              className="text-blue-700 font-medium flex items-center gap-1 mb-4 hover:underline"
            >
              <ArrowLeft className="h-4 w-4" /> Back to accounts
            </Link>
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setLeftTab("accountInfo")}
                className={`px-3 py-1.5 rounded-lg text-sm font-semibold shadow-sm transition ${
                  leftTab === "accountInfo" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-500"
                }`}
              >
                About Account
              </button>
              <button
                onClick={() => setLeftTab("addressInfo")}
                className={`px-3 py-1.5 rounded-lg text-sm font-semibold shadow-sm transition ${
                  leftTab === "addressInfo" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-500"
                }`}
              >
                Address Info
              </button>
            </div>
            {leftTab === "accountInfo" && (
              <div className="text-sm text-gray-700 space-y-2">
                <div><span className="font-semibold">Industry:</span> {account.industry}</div>
                <div><span className="font-semibold">Phone:</span> {account.phone}</div>
                <div><span className="font-semibold">Website:</span> {account.website}</div>
                <div><span className="font-semibold">Type:</span> {account.type}</div>
                <div><span className="font-semibold">Last contacted:</span> -</div>
                <div><span className="font-semibold">Account owner:</span> {account.owner || "-"}</div>
              </div>
            )}
            {leftTab === "addressInfo" && (
              <div className="text-sm text-gray-700">
                <div><span className="font-semibold">Street:</span> {account.street || "-"}</div>
                <div><span className="font-semibold">City:</span> {account.city || "-"}</div>
                <div><span className="font-semibold">State:</span> {account.state || "-"}</div>
                <div><span className="font-semibold">Country:</span> {account.country || "-"}</div>
                <div><span className="font-semibold">Postal Code:</span> {account.postalCode || "-"}</div>
              </div>
            )}
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-6">
            <h3 className="font-semibold mb-2 text-gray-800 flex items-center">
              <FileText className="h-5 w-5 mr-2" /> Files
            </h3>
            <ul className="space-y-2">
              {files.map(file => (
                <li key={file.name} className="flex items-center justify-between text-sm">
                  <a href={file.url} className="text-blue-700 hover:underline">{file.name}</a>
                  <span className="text-xs text-gray-400">{file.uploaded}</span>
                </li>
              ))}
            </ul>
            <button className="mt-3 px-3 py-1 bg-blue-50 text-blue-700 rounded hover:bg-blue-100 text-xs font-medium">
              Upload File
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="lg:col-span-6 flex flex-col gap-6">
          <div className="flex gap-2 border-b pb-2">
            <button
              onClick={() => setMainTab("overview")}
              className={`px-4 py-2 rounded-t-lg font-semibold text-base ${
                mainTab === "overview" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setMainTab("activities")}
              className={`px-4 py-2 rounded-t-lg font-semibold text-base ${
                mainTab === "activities" ? "bg-blue-50 text-blue-700" : "text-gray-600 hover:text-blue-700"
              }`}
            >
              Activities
            </button>
          </div>
          {mainTab === "overview" && (
            <div className="bg-white rounded-xl border border-indigo-100 shadow-sm p-6">
              <h3 className="font-semibold text-gray-800 mb-4">Overview</h3>
              <p className="text-gray-700">
                {account.description || "No description available."}
              </p>
              <div className="mt-6 flex gap-4">
                <div className="bg-green-50 text-green-700 px-4 py-2 rounded-lg font-semibold text-sm flex items-center gap-2">
                  <Star className="h-4 w-4" /> Account Score: {qualification.score}
                </div>
                <div className="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg font-semibold text-sm flex items-center gap-2">
                  <Bell className="h-4 w-4" /> Next Action: Schedule follow-up call
                </div>
              </div>
            </div>
          )}
          {mainTab === "activities" && (
            <>
              <input
                type="text"
                className="w-full border border-gray-200 rounded-lg px-4 py-2 mb-4 bg-gray-50 text-base"
                placeholder="Search activity, notes, email and more..."
              />
              <div className="flex gap-2 mb-4 flex-wrap">
                {activityTypes.map(({ icon: IconComp, label }) => (
                  <button
                    key={label}
                    type="button"
                    onClick={() => setActivityType(label)}
                    className={`flex items-center gap-1 px-3 py-1 rounded-lg text-sm font-medium transition ${
                      activityType === label
                        ? "bg-blue-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-blue-50"
                    }`}
                  >
                    <IconComp className="h-4 w-4" /> {label}
                  </button>
                ))}
              </div>
              <div className="bg-white border border-indigo-100 rounded-xl p-5 mb-6 shadow-sm">
                {activityType === "Notes" && (
                  <>
                    <div className="mb-2 font-semibold text-gray-700">Add new note</div>
                    <input
                      type="text"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 mb-2 bg-gray-50"
                      placeholder="Summary Meeting 12 Jul, 2025"
                    />
                    <textarea
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 mb-2 bg-gray-50"
                      placeholder="This is"
                      rows={2}
                    />
                    <div className="flex gap-2 items-center">
                      <button className="px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold text-sm shadow hover:bg-blue-700 transition">
                        Add note
                      </button>
                      <span className="text-xs text-gray-400">Associated with 3 records</span>
                    </div>
                  </>
                )}
                {activityType === "Emails" && (
                  <div className="text-gray-700 w-full">Show email activity or email composer here.</div>
                )}
                {activityType === "Calls" && (
                  <div className="text-gray-700 w-full">Show call logs or call notes here.</div>
                )}
                {activityType === "Task" && (
                  <div className="text-gray-700 w-full">Show tasks or task creation form here.</div>
                )}
                {activityType === "Meetings" && (
                  <div className="text-gray-700 w-full">Show meetings or meeting notes here.</div>
                )}
                {activityType === "Activity" && (
                  <div className="text-gray-700 w-full">Show all activities here.</div>
                )}
              </div>
              <div className="bg-white rounded-xl border border-indigo-100 shadow-sm p-6">
                <div className="mb-2 text-gray-500 text-xs">June 2025</div>
                {account.transcript?.map((t: any, i: number) => (
                  <div key={i} className="mb-4">
                    <div className="mb-1 text-xs text-gray-400">
                      <span className="font-semibold">{t.who}:</span>
                    </div>
                    <div className="text-gray-700">{t.text}</div>
                  </div>
                ))}
              </div>
            </>
          )}
        </main>

        {/* Right Sidebar */}
        <aside className="lg:col-span-3 flex flex-col gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-6">
            <h3 className="font-semibold mb-2 text-gray-800">Contacts</h3>
            <div className="space-y-3">
              {account.contacts?.map((contact: any, i: number) => (
                <div key={i} className="border border-gray-100 rounded-lg p-4">
                  <div className="flex items-center gap-2">
                    <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full text-xs font-medium">
                      {contact.title}
                    </span>
                  </div>
                  <div className="font-medium text-gray-900 mt-1">{contact.name}</div>
                  <div className="flex items-center gap-2 mt-1">
                    <MailOpen className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-600">{contact.email}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-600">{contact.phone}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-6">
            <h3 className="font-semibold mb-2 text-gray-800">AI-Generated Insights</h3>
            <div className="text-sm text-gray-700">
              <div className="mb-2">
                <span className="font-semibold">Recent News:</span>
                <span className="italic text-gray-400 ml-2">{account.aiInsights?.news || "No recent news"}</span>
              </div>
              <div className="mb-2">
                <span className="font-semibold">Potential Pain Points</span>
                <ul className="list-disc ml-6">
                  {(account.aiInsights?.painPoints || []).map((p: string, i: number) => (
                    <li key={i}>{p}</li>
                  ))}
                </ul>
              </div>
              <div>
                <span className="font-semibold">Conversation Intelligence:</span>
                <span className="italic text-gray-400 ml-2">{account.aiInsights?.intelligence || "No data"}</span>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default AccountDetail;
