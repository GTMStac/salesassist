import React, { useEffect, useState } from "react";
import { supabase } from "../supabaseClient";
import { getGeminiInsights } from "../services/geminiAI";

export default function AgentDashboard() {
  const [prospects, setProspects] = useState<any[]>([]);
  const [sendingId, setSendingId] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    fetchProspects();
  }, []);

  async function fetchProspects() {
    const { data, error } = await supabase.from("prospects").select("*");
    if (error) {
      setMessage("Failed to fetch prospects.");
      return;
    }
    setProspects(data || []);
  }

  // Call backend to send the initial email
  const handleSendEmail = async (prospect: any) => {
    setSendingId(prospect.id);
    setMessage(null);
    try {
      // Generate email body using Gemini
      const emailBody = await getGeminiInsights(
        `Write a friendly intro email about our product to ${prospect.name}.`
      );
      // Call backend API to send email
      const response = await fetch("/api/send-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: prospect.email,
          subject: "Introducing Our Product",
          text: emailBody,
        }),
      });
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Failed to send email");
      }
      setMessage(`Initial email sent to ${prospect.name}!`);
      await fetchProspects();
    } catch (err) {
      setMessage(
        `Failed to send email: ${err instanceof Error ? err.message : String(err)}`
      );
    }
    setSendingId(null);
  };

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Automate Mail Agent</h2>
      <p className="mb-6 text-slate-600">
        This AI agent automatically sends emails, tracks replies, follows up, and schedules demos.
      </p>
      {message && (
        <div className="mb-4 p-2 rounded bg-blue-100 text-blue-800">{message}</div>
      )}
      <table className="min-w-full bg-white border rounded-lg shadow">
        <thead>
          <tr>
            <th className="px-3 py-2 border-b">Name</th>
            <th className="px-3 py-2 border-b">Email</th>
            <th className="px-3 py-2 border-b">Status</th>
            <th className="px-3 py-2 border-b">Follow-ups</th>
            <th className="px-3 py-2 border-b">Demo Time</th>
            <th className="px-3 py-2 border-b">Actions</th>
          </tr>
        </thead>
        <tbody>
          {prospects.map((p) => (
            <tr key={p.id}>
              <td className="px-3 py-2 border-b">{p.name}</td>
              <td className="px-3 py-2 border-b">{p.email}</td>
              <td className="px-3 py-2 border-b">{p.status}</td>
              <td className="px-3 py-2 border-b">{p.followup_count}</td>
              <td className="px-3 py-2 border-b">{p.demo_time || "-"}</td>
              <td className="px-3 py-2 border-b">
                <button
                  className={`bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700 disabled:opacity-50`}
                  onClick={() => handleSendEmail(p)}
                  disabled={
                    sendingId === p.id ||
                    p.status !== "active" ||
                    (p.followup_count && p.followup_count > 0)
                  }
                >
                  {sendingId === p.id ? "Sending..." : "Send Email"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
