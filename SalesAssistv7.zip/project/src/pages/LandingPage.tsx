import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Bot, Zap, Search, Bell, Mail, Clock, Shield, Cpu, Sun, Moon
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// Animated glowing line for CTA
const GlowingLine = () => (
  <motion.div
    initial={{ opacity: 0.2, scaleX: 0.8 }}
    animate={{ opacity: [0.2, 1, 0.2], scaleX: [0.8, 1, 0.8] }}
    transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
    className="h-0.5 w-40 bg-gradient-to-r from-blue-400/0 via-blue-500 to-blue-400/0 blur-sm"
  />
);

// Typewriter search bar
function TypewriterSearch({ text, typingSpeed, typing, onDone }) {
  const [displayed, setDisplayed] = useState("");
  useEffect(() => {
    if (!typing) return;
    setDisplayed("");
    let i = 0;
    function type() {
      setDisplayed(text.slice(0, i + 1));
      if (i < text.length - 1) {
        i++;
        setTimeout(type, typingSpeed);
      } else if (onDone) {
        setTimeout(onDone, 100);
      }
    }
    type();
  }, [text, typing, typingSpeed, onDone]);
  return (
    <span className="font-mono text-base" style={{ color: "inherit" }}>
      {displayed}
      <span
        style={{
          display: "inline-block",
          width: "1ch",
          animation: typing ? "blink 1s steps(1) infinite" : "none",
        }}
      >
        |
      </span>
      <style>
        {`
        @keyframes blink { 50% { opacity: 0; } }
      `}
      </style>
    </span>
  );
}

// Paragraph-style AI agent response
function AnimatedAIParagraph({ text, theme }) {
  return (
    <motion.div
      key="ai"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      className={`w-full mt-2 rounded-lg p-4 border ${theme === "dark" ? "bg-[#181f31] border-blue-900 text-blue-100" : "bg-white border-gray-200 text-gray-700"}`}
    >
      <div className="flex items-center gap-2 mb-2">
        <Zap className={`h-5 w-5 ${theme === "dark" ? "text-blue-400" : "text-blue-500"}`} />
        <span className={theme === "dark" ? "text-blue-100 font-semibold" : "text-gray-700 font-semibold"}>AI Agent</span>
      </div>
      <div>{text}</div>
    </motion.div>
  );
}

const prompts = [
  "Show me all opportunities closing this month",
  "Summarize the pipeline for Q2",
  "List the top 3 opportunities by value",
];

const aiParagraphs = [
  "Here are all opportunities expected to close this month: Acme Corp ($120,000), Globex Inc ($85,000), and Umbrella Ltd ($60,000). These deals are in the final negotiation stages and could significantly boost this quarter's revenue.",
  "The Q2 pipeline consists of 5 deals in Discovery, 3 in Proposal, and 2 in Negotiation. The total pipeline value is $400,000, with the majority of opportunities concentrated in the SaaS and Healthcare sectors.",
  "The top 3 opportunities by value are Acme Corp ($340,000), Stark Industries ($220,000), and Wayne Enterprises ($180,000). Focusing on these accounts could maximize your team's win rate this quarter.",
];

// Dashboard Section
function Dashboard({ theme }) {
  const [currentPrompt, setCurrentPrompt] = useState(0);
  const [phase, setPhase] = useState('typing');
  const [showThinking, setShowThinking] = useState(false);

  const typingSpeed = 60;
  const waitAfterPrompt = 2000;
  const thinkingTime = 2000;
  const resultDisplayDuration = 5000;

  useEffect(() => {
    let timeout = null;
    if (phase === 'waiting') {
      timeout = setTimeout(() => setPhase('thinking'), waitAfterPrompt);
    } else if (phase === 'thinking') {
      timeout = setTimeout(() => setPhase('result'), thinkingTime);
    } else if (phase === 'result') {
      if (currentPrompt < prompts.length - 1) {
        timeout = setTimeout(() => {
          setCurrentPrompt(p => p + 1);
          setPhase('typing');
        }, resultDisplayDuration);
      }
    }
    return () => { if (timeout) clearTimeout(timeout); };
  }, [phase, currentPrompt]);

  useEffect(() => {
    setShowThinking(phase === 'thinking');
  }, [phase]);

  return (
    <section className={`flex justify-center items-center pb-20 ${theme === "dark" ? "bg-gradient-to-b from-[#0a0e17] to-[#10182a]" : "bg-white"}`}>
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className={`rounded-3xl overflow-hidden flex shadow-2xl border ${theme === "dark" ? "border-blue-700" : "border-gray-200"}`}
        style={{ background: theme === "dark" ? "rgba(15,20,34,0.96)" : "#fff", width: 1100, maxWidth: "98vw" }}
      >
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-8">
            <span className={`text-2xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}>Dashboard</span>
            <div className="flex items-center gap-4">
              <div className="relative">
                <input
                  type="text"
                  disabled
                  value=""
                  placeholder="Search"
                  className={`rounded-md px-3 py-1.5 focus:outline-none ${theme === "dark" ? "bg-[#181f31] border-[#232a3a] text-blue-100 border" : "bg-gray-100 border border-gray-200 text-gray-700"}`}
                  style={{ width: 160 }}
                />
                <Search className={`absolute right-2 top-2 h-4 w-4 ${theme === "dark" ? "text-blue-300" : "text-gray-400"}`} />
              </div>
              <Bell className={`h-6 w-6 ${theme === "dark" ? "text-blue-200" : "text-gray-400"}`} />
              <img
                src="https://randomuser.me/api/portraits/men/32.jpg"
                alt="User"
                className={`h-8 w-8 rounded-full border-2 ${theme === "dark" ? "border-blue-700" : "border-gray-300"}`}
              />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-6 mb-8">
            {[
              ["Leads", "+150", "Compare to 120 Last Month"],
              ["Opportunities", "+80", "Compare to 60 Last Month"],
              ["Accounts", "+35", "Compare to 30 Last Month"],
            ].map(([title, value, sub], i) => (
              <div
                key={title}
                className={`rounded-xl p-6 border ${theme === "dark" ? "bg-[#181f31] border-blue-900 text-white" : "bg-white border-gray-200 text-gray-900"}`}
              >
                <div className="flex items-center justify-between">
                  <span>{title}</span>
                  <span className={theme === "dark" ? "text-blue-400" : "text-blue-500"}>{value}</span>
                </div>
                <div className="text-xs text-gray-400">{sub}</div>
                <div className={`mt-4 h-8 w-full rounded ${theme === "dark" ? "bg-gradient-to-r from-blue-600/30 to-transparent" : "bg-gray-100"}`} />
              </div>
            ))}
          </div>
          <div className="flex items-center mb-3">
            <div
              className={`flex-1 rounded-md px-4 py-2 font-mono text-base border ${theme === "dark" ? "bg-[#181f31] border-[#232a3a] text-blue-100" : "bg-gray-100 border-gray-200 text-gray-700"}`}
            >
              <TypewriterSearch
                text={prompts[currentPrompt]}
                typingSpeed={typingSpeed}
                typing={phase === 'typing'}
                onDone={() => setPhase('waiting')}
              />
            </div>
            <button
              className={`ml-3 px-5 py-2 rounded-lg font-semibold ${theme === "dark" ? "bg-blue-600 text-white" : "bg-blue-500 text-white"}`}
              style={{ opacity: 0.5, cursor: "not-allowed" }}
              disabled
            >
              Ask
            </button>
          </div>
          <AnimatePresence>
            {showThinking && (
              <motion.div
                key="thinking"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className={`w-full mt-2 rounded-lg p-4 border ${theme === "dark" ? "bg-[#181f31] border-blue-900 text-blue-100" : "bg-white border-gray-200 text-gray-700"}`}
              >
                <motion.span
                  animate={{ opacity: [1, 0.2, 1] }}
                  transition={{ repeat: Infinity, duration: 1 }}
                >
                  <Zap className={`inline h-5 w-5 mr-2 ${theme === "dark" ? "text-blue-400" : "text-blue-500"}`} />
                  AI Agent is thinking...
                </motion.span>
              </motion.div>
            )}
            {phase === 'result' && (
              <AnimatedAIParagraph text={aiParagraphs[currentPrompt]} theme={theme} />
            )}
          </AnimatePresence>
          <div className="grid grid-cols-2 gap-6 mt-8">
            <div className={`rounded-xl p-6 border ${theme === "dark" ? "bg-[#181f31] border-blue-900 text-white" : "bg-white border-gray-200 text-gray-900"}`}>
              <div className="font-semibold mb-2">Predictive Analytics</div>
              <div className="h-32 flex items-center justify-center">
                <svg width="180" height="60">
                  <polyline
                    fill="none"
                    stroke="#2563eb"
                    strokeWidth="3"
                    points="0,50 30,35 60,45 90,20 120,40 150,25 180,35"
                  />
                  <circle cx="30" cy="35" r="6" fill="#2563eb" />
                  <circle cx="90" cy="20" r="6" fill="#2563eb" />
                  <circle cx="150" cy="25" r="6" fill="#2563eb" />
                  <text x="20" y="30" fill="#2563eb" fontSize="10">10k+</text>
                  <text x="80" y="15" fill="#2563eb" fontSize="10">10k+</text>
                  <text x="140" y="20" fill="#2563eb" fontSize="10">10k+</text>
                </svg>
              </div>
            </div>
            <div className={`rounded-xl p-6 border ${theme === "dark" ? "bg-[#181f31] border-blue-900 text-white" : "bg-white border-gray-200 text-gray-900"}`}>
              <div className="font-semibold mb-2">Strongest Niche</div>
              {[
                ["Data Process", 79],
                ["Optimize", 40],
                ["Data Analysis", 35],
                ["Data Alignment", 70]
              ].map(([label, percent], i) => (
                <div className="mb-4" key={label}>
                  <div className={`flex justify-between text-xs mb-1 ${theme === "dark" ? "text-blue-200" : "text-gray-500"}`}>
                    <span>{label}</span>
                    <span>{percent}% Correct</span>
                  </div>
                  <div className={`w-full h-2 rounded ${theme === "dark" ? "bg-[#232a3a]" : "bg-gray-100"}`}>
                    <div className="h-2 bg-blue-500 rounded" style={{ width: `${percent}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </motion.div>
    </section>
  );
}

// Robot Icon for AI Agents
function RobotIcon() {
  return (
    <svg width="80" height="80" viewBox="0 0 100 100">
      <rect x="25" y="20" width="50" height="60" rx="10" fill="#3b82f6" />
      <circle cx="40" cy="40" r="8" fill="white" />
      <circle cx="60" cy="40" r="8" fill="white" />
      <rect x="40" y="60" width="20" height="10" rx="5" fill="#dbeafe" />
    </svg>
  );
}

// AI Agents Animation Section
function AIAgentsAnimation({ theme }) {
  return (
    <section className={`max-w-7xl mx-auto px-6 py-16 ${theme === "dark" ? "bg-[#10182a]" : "bg-white"} rounded-2xl shadow-lg`}>
      <h2 className={`text-3xl font-bold text-center mb-12 ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
        AI Agents in Action
      </h2>
      <div className="grid md:grid-cols-3 gap-8">
        {/* 1. AI agent communicating with another */}
        <div className="flex flex-col items-center">
          <motion.div
            className="relative"
            animate={{ y: [0, -10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            <RobotIcon />
            <motion.svg
              width="120"
              height="40"
              className="absolute top-1/2 left-full"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 1, 0] }}
              transition={{ repeat: Infinity, duration: 2, delay: 1 }}
            >
              <polyline
                points="10,20 90,20"
                stroke="#4f46e5"
                strokeWidth="3"
                strokeLinecap="round"
                fill="none"
              />
              <circle cx="90" cy="20" r="5" fill="#4f46e5" />
            </motion.svg>
          </motion.div>
          <p className={`mt-4 font-semibold text-lg ${theme === "dark" ? "text-blue-100" : "text-slate-700"}`}>
            AI Agent Communicating with Another
          </p>
        </div>

        {/* 2. AI agents solving business challenges */}
        <div className="flex flex-col items-center">
          <div className="flex gap-4 items-center">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <RobotIcon />
            </motion.div>
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 2, delay: 0.5 }}
            >
              <RobotIcon />
            </motion.div>
          </div>
          <p className={`mt-4 font-semibold text-lg ${theme === "dark" ? "text-blue-100" : "text-slate-700"}`}>
            AI Agents Solving Business Challenges
          </p>
        </div>

        {/* 3. AI agents collaborating as a team */}
        <div className="flex flex-col items-center">
          <div className="flex flex-wrap justify-center gap-2">
            {[1, 2, 3, 4].map((i) => (
              <motion.div
                key={i}
                animate={{ y: [0, -5, 0], opacity: [0.9, 1, 0.9] }}
                transition={{ repeat: Infinity, duration: 2, delay: i * 0.2 }}
              >
                <RobotIcon />
              </motion.div>
            ))}
          </div>
          <p className={`mt-4 font-semibold text-lg ${theme === "dark" ? "text-blue-100" : "text-slate-700"}`}>
            AI Agents Collaborating as a Team
          </p>
        </div>
      </div>
    </section>
  );
}

// Main Landing Page
export default function LandingPage() {
  const [theme, setTheme] = useState("light");

  useEffect(() => {
    const hour = new Date().getHours();
    setTheme(hour >= 6 && hour < 18 ? "light" : "dark");
  }, []);

  useEffect(() => {
    localStorage.setItem("gtm-theme", theme);
  }, [theme]);

  useEffect(() => {
    const stored = localStorage.getItem("gtm-theme");
    if (stored) setTheme(stored);
  }, []);

  const toggleTheme = () => setTheme(theme === "light" ? "dark" : "light");

  const bgMain = theme === "dark"
    ? "bg-gradient-to-b from-[#0a0e17] via-[#10182a] to-[#10182a]"
    : "bg-white";
  const textMain = theme === "dark" ? "text-white" : "text-gray-900";
  const textSecondary = theme === "dark" ? "text-blue-100" : "text-gray-600";
  const headerBg = theme === "dark" ? "bg-[#0a0e17] border-b border-[#22263a]" : "bg-white border-b border-gray-200";
  const navLink = theme === "dark" ? "text-gray-300 hover:text-white" : "text-gray-700 hover:text-blue-500";

  return (
    <div className={`min-h-screen font-sora transition-colors duration-500 ${bgMain}`}>
      {/* Header */}
      <header className={`sticky top-0 z-50 font-sora ${headerBg}`}>
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between h-16">
          <div className="flex flex-col items-start">
            <div className="flex items-center">
              <Bot className="h-8 w-8 text-blue-500" />
              <span className={`ml-2 text-2xl font-black tracking-tight ${textMain}`}>GTM Stac</span>
            </div>
            <span className={`ml-10 text-sm font-medium ${theme === "dark" ? "text-blue-300" : "text-gray-500"}`}>Sales AI Assistant</span>
          </div>
          <nav className="hidden md:flex space-x-8">
            <Link to="/product" className={navLink}>Product</Link>
            <Link to="/solutions" className={navLink}>Solutions</Link>
            <Link to="/resources" className={navLink}>Resources</Link>
            <Link to="/company" className={navLink}>Company</Link>
          </nav>
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleTheme}
              className="flex items-center justify-center rounded-full transition-colors duration-500 focus:outline-none"
              style={{
                width: 40,
                height: 40,
                background: theme === "light" ? "#fff" : "#181f31",
                border: theme === "light" ? "1px solid #e0e0e0" : "1px solid #232a3a",
                boxShadow: theme === "light" ? "0 0 8px #e0e0e0" : "none"
              }}
              title={theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
            >
              {theme === "light" ? (
                <Moon width={24} height={24} color="#181f31" />
              ) : (
                <Sun width={24} height={24} color="#fff" />
              )}
            </button>
            <Link
              to="/auth"
              className={theme === "dark"
                ? "text-gray-300 hover:text-blue-400"
                : "text-gray-700 hover:text-blue-500"}
            >
              Login
            </Link>
            <Link
              to="/signup"
              className={theme === "dark"
                ? "bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors font-semibold"
                : "bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors font-semibold"}
            >
              Sign Up
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className={`flex flex-col items-center justify-center py-20 ${theme === "dark" ? "bg-gradient-to-b from-[#0a0e17] to-[#10182a]" : "bg-white"}`}>
        <h1 className={`text-4xl md:text-5xl font-extrabold text-center mb-4 ${textMain}`}>
          Supercharge Your Sales with AI
        </h1>
        <p className={`text-lg md:text-xl text-center max-w-2xl mb-10 ${textSecondary}`}>
          GTM Stac is the intelligent sales assistant that empowers your team to close more deals, faster. Leverage AI to automate tasks, gain deep insights, and personalize your outreach.
        </p>
        <div className="flex items-center">
          <GlowingLine />
          <motion.div
            initial={{ boxShadow: '0 0 0 0 #2563eb' }}
            animate={{ boxShadow: ['0 0 0 0 #2563eb', '0 0 16px 4px #2563eb', '0 0 0 0 #2563eb'] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
            className="mx-8 rounded-xl"
          >
            <button
              className={`relative z-10 px-14 py-5 rounded-xl text-lg font-semibold border border-blue-500 hover:bg-blue-900 transition ${theme === "dark" ? "bg-[#10182a] text-white" : "bg-blue-500 text-white hover:bg-blue-600"}`}
            >
              Get Started for Free
            </button>
          </motion.div>
          <GlowingLine />
        </div>
      </section>

      {/* Dashboard */}
      <Dashboard theme={theme} />

      {/* AI Agents Animation */}
      <AIAgentsAnimation theme={theme} />

      {/* AI-Driven Features Section */}
      <section id="features" className={`py-20 ${theme === "dark" ? "bg-[#10182a]" : "bg-white"}`}>
        <div className="max-w-6xl mx-auto px-4">
          <h2 className={`text-3xl md:text-4xl font-bold text-center mb-4 tracking-tight ${textMain}`}>
            <span className="text-blue-500">AI-Driven</span> Features
          </h2>
          <p className={`text-lg text-center mb-14 ${textSecondary}`}>
            Unlock the Full Potential of Your Data with Advanced AI Solutions
          </p>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Zap className="h-8 w-8 text-blue-500" />,
                title: "AI Workflow Automation",
                desc: "Automate repetitive and time-consuming tasks with our AI-powered workflow automation.",
                svg: (
                  <svg width="180" height="60">
                    <polyline points="0,50 40,30 80,40 120,10 160,30 180,20" fill="none" stroke="#2563eb" strokeWidth="3" />
                  </svg>
                )
              },
              {
                icon: <Mail className="h-8 w-8 text-blue-500" />,
                title: "Natural Language Processing (NLP) Engine",
                desc: "Automate communication and extract insights from unstructured data using advanced NLP.",
                svg: (
                  <svg width="180" height="80">
                    <rect x="10" y="40" width="20" height="30" fill={theme === "dark" ? "#181f31" : "#f3f4f6"} />
                    <rect x="40" y="30" width="20" height="40" fill={theme === "dark" ? "#181f31" : "#f3f4f6"} />
                    <rect x="70" y="20" width="20" height="50" fill={theme === "dark" ? "#181f31" : "#f3f4f6"} />
                    <rect x="100" y="10" width="20" height="60" fill={theme === "dark" ? "#181f31" : "#f3f4f6"} />
                    <rect x="130" y="25" width="20" height="45" fill={theme === "dark" ? "#181f31" : "#f3f4f6"} />
                    <polyline points="10,70 50,50 90,60 130,30 150,40" fill="none" stroke="#2563eb" strokeWidth="3" />
                  </svg>
                )
              },
              {
                icon: <Cpu className="h-8 w-8 text-blue-500" />,
                title: "AI-Powered Decision-Making",
                desc: "Make smarter, faster decisions with real-time AI insights and predictive analytics.",
                svg: (
                  <svg width="80" height="60">
                    <circle cx="40" cy="30" r="20" fill="none" stroke="#2563eb" strokeWidth="3" />
                    <circle cx="40" cy="30" r="8" fill="#2563eb" />
                  </svg>
                )
              }
            ].map((card, i) => (
              <div
                key={card.title}
                className={`p-8 rounded-2xl shadow border ${theme === "dark" ? "bg-[#181f31] border-blue-900" : "bg-white border-gray-200"}`}
              >
                <div className="flex items-center gap-3 mb-4">
                  {card.icon}
                  <span className={`font-semibold text-lg ${textMain}`}>{card.title}</span>
                </div>
                <p className={`mb-4 ${theme === "dark" ? "text-blue-100" : "text-gray-700"}`}>{card.desc}</p>
                <div className="h-32 flex items-center justify-center">{card.svg}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose GTM Stac */}
      <section id="why" className={`py-20 ${theme === "dark" ? "bg-[#0a0e17]" : "bg-white"}`}>
        <div className="max-w-4xl mx-auto px-4">
          <h2 className={`text-3xl md:text-4xl font-bold text-center mb-4 tracking-tight ${textMain}`}>
            Why Choose GTM Stac?
          </h2>
          <p className={`text-center mb-12 ${textSecondary}`}>
            We provide the tools and intelligence your sales team needs to excel in today's competitive market.
          </p>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Clock className="h-10 w-10 text-blue-500 mb-4" />,
                title: "Increase Efficiency",
                desc: "Spend less time on manual tasks and more time selling. Our AI handles the repetitive work so your team can focus on building relationships and closing deals."
              },
              {
                icon: <Zap className="h-10 w-10 text-blue-500 mb-4" />,
                title: "Boost Conversion Rates",
                desc: "Identify the most promising leads and engage them with personalized communication at the right time, significantly improving your chances of success."
              },
              {
                icon: <Shield className="h-10 w-10 text-blue-500 mb-4" />,
                title: "Gain Deeper Insights",
                desc: "Understand your customers and market dynamics like never before. Make data-driven decisions to optimize your sales strategy and outperform the competition."
              }
            ].map(card => (
              <div
                key={card.title}
                className={`p-8 rounded-2xl shadow border flex flex-col items-center ${theme === "dark" ? "bg-[#181f31] border-blue-900" : "bg-white border-gray-200"}`}
              >
                {card.icon}
                <h3 className={`text-lg font-semibold mb-2 ${textMain}`}>{card.title}</h3>
                <p className={`${theme === "dark" ? "text-blue-100" : "text-gray-700"} text-center`}>{card.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Integrations Marquee */}
      <section id="integrations" className={`py-16 ${theme === "dark" ? "bg-[#10182a]" : "bg-white"}`}>
        <h2 className={`text-3xl font-bold text-center mb-8 ${textMain}`}>Integrations</h2>
        <div className="overflow-x-hidden">
          <motion.div
            animate={{ x: ['0%', '-50%'] }}
            transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            className="flex gap-16 w-max"
            style={{ minWidth: '200%' }}
          >
            {[
              { src: "/integrations/salesforce.svg", alt: "Salesforce" },
              { src: "/integrations/hubspot.svg", alt: "HubSpot" },
              { src: "/integrations/marketo.svg", alt: "Marketo" },
              { src: "/integrations/lusha.svg", alt: "Lusha" },
              { src: "/integrations/kendo.svg", alt: "Kendo" },
              { src: "/integrations/zoominfo.svg", alt: "ZoomInfo" },
              { src: "/integrations/google-calendar.svg", alt: "Google Calendar" },
              { src: "/integrations/gmail.svg", alt: "Gmail" },
              { src: "/integrations/outreach.svg", alt: "Outreach" },
              { src: "/integrations/linkedin-sales-navigator.svg", alt: "LinkedIn Sales Navigator" },
              { src: "/integrations/tableau.svg", alt: "Tableau" },
              { src: "/integrations/power-bi.svg", alt: "Power BI" },
            ].map((logo, i) => (
              <img
                key={logo.alt + i}
                src={logo.src}
                alt={logo.alt}
                className="h-12 grayscale hover:grayscale-0 transition duration-300"
                style={{ background: "transparent" }}
              />
            ))}
            {[
              { src: "/integrations/salesforce.svg", alt: "Salesforce" },
              { src: "/integrations/hubspot.svg", alt: "HubSpot" },
              { src: "/integrations/marketo.svg", alt: "Marketo" },
              { src: "/integrations/lusha.svg", alt: "Lusha" },
              { src: "/integrations/kendo.svg", alt: "Kendo" },
              { src: "/integrations/zoominfo.svg", alt: "ZoomInfo" },
              { src: "/integrations/google-calendar.svg", alt: "Google Calendar" },
              { src: "/integrations/gmail.svg", alt: "Gmail" },
              { src: "/integrations/outreach.svg", alt: "Outreach" },
              { src: "/integrations/linkedin-sales-navigator.svg", alt: "LinkedIn Sales Navigator" },
              { src: "/integrations/tableau.svg", alt: "Tableau" },
              { src: "/integrations/power-bi.svg", alt: "Power BI" },
            ].map((logo, i) => (
              <img
                key={logo.alt + "r" + i}
                src={logo.src}
                alt={logo.alt}
                className="h-12 grayscale hover:grayscale-0 transition duration-300"
                style={{ background: "transparent" }}
              />
            ))}
          </motion.div>
        </div>
      </section>

      {/* Final CTA */}
      <section className={`py-24 text-center ${theme === "dark" ? "bg-gradient-to-br from-blue-900 via-[#0a0e17] to-blue-800" : "bg-white"}`}>
        <h2 className={`text-4xl md:text-5xl font-extrabold mb-6 ${textMain}`}>
          Ready to Automate Your <br /> Business <br /> <span className="text-blue-500">with AI?</span>
        </h2>
        <div className="flex justify-center mt-8">
          <motion.button
            whileHover={{ scale: 1.07, boxShadow: "0 0 24px 8px #2563eb88" }}
            className={`px-12 py-4 rounded-xl text-lg font-semibold border shadow-lg transition ${theme === "dark" ? "bg-blue-600 text-white border-blue-400" : "bg-blue-500 text-white border-blue-400 hover:bg-blue-600"}`}
          >
            Get Started for Free
          </motion.button>
        </div>
      </section>

      {/* Footer */}
      <footer className={theme === "dark" ? "bg-[#0a0e17] py-8" : "bg-white py-8"}>
        <div className={`max-w-7xl mx-auto px-4 text-center ${theme === "dark" ? "text-blue-200" : "text-gray-500"}`}>
          <p>© {new Date().getFullYear()} GTM Stac. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
