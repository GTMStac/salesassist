import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../supabaseClient';

const CallbackPage = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // First, check if a session already exists (user is signed in)
    const checkSession = async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        navigate('/dashboard');
      }
    };
    checkSession();

    // Listen for auth state changes (for when Supabase processes the OAuth callback)
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        navigate('/dashboard');
      } else {
        navigate('/auth');
      }
    });

    // Cleanup: unsubscribe on unmount
    return () => {
      listener.subscription.unsubscribe();
    };
  }, [navigate]);

  return <div>Signing you in...</div>;
};

export default CallbackPage;
