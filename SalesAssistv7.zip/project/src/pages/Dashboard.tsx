import React from 'react';
import { Link } from 'react-router-dom';
import { useSalesforce } from '../context/SalesforceContext';
import StatCard from '../components/dashboard/StatCard';
import OpportunityChart from '../components/dashboard/OpportunityChart';
import RecentActivityCard from '../components/dashboard/RecentActivity';
import ActionCard from '../components/dashboard/ActionCard';
import PipelineHealthCard from '../components/dashboard/PipelineHealthCard';
import HighScoringLeadsCard from '../components/dashboard/HighScoringLeadsCard';
import WelcomeCard from '../components/dashboard/WelcomeCard';
import SearchBar from '../components/layout/SearchBar';
import { Users, Briefcase, PhoneCall, TrendingUp, BarChart2, DollarSign } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
const { leads, accounts, contacts, opportunities, loading } = useSalesforce();
const { user } = useAuth();

// User display name logic
let firstName = user?.user_metadata?.first_name || '';
let lastName = user?.user_metadata?.last_name || '';
const fullName =
user?.user_3metadata?.full_name ||
user?.user_metadata?.name ||
user?.email ||
'User';

if ((!firstName || !lastName) && fullName) {
const parts = fullName.split(' ');
firstName = parts[0];
lastName = parts.slice(1).join(' ');
}
const displayName = `${firstName} ${lastName}`.trim() || fullName;

// Opportunity data for chart
const opportunityStages = ['Discovery', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost'];
const opportunityData = {
labels: opportunityStages,
datasets: [
{
label: 'Value ($)',
data: opportunityStages.map(stage =>
opportunities
.filter(opp => opp.stage === stage)
.reduce((sum, opp) => sum + (opp.amount || 0), 0)
),
backgroundColor: '#0B5CFF80', // 50% opacity
borderColor: '#0B5CFF',
borderWidth: 1,
},
],
};

// Total revenue for goal progress
const totalRevenue = opportunities
.filter(opp => opp.stage === 'Closed Won')
.reduce((sum, opp) => sum + (opp.amount || 0), 0);

// High-scoring leads
const highScoringLeads = leads.filter(lead => lead.leadScore && lead.leadScore > 75);

if (loading) {
return (
<div className="space-y-6 bg-white dark:bg-gray-900 min-h-screen p-6">
<h1 className="text-2xl font-bold text-black dark:text-white">Dashboard</h1>
<div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
{[1, 2, 3, 4, 5].map((i) => (
<div key={i} className="h-32 animate-pulse rounded-xl bg-[#0B5CFF]/10 dark:bg-gray-800"></div>
))}
</div>
<div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
<div className="h-96 animate-pulse rounded-xl bg-[#0B5CFF]/10 dark:bg-gray-800"></div>
<div className="h-96 animate-pulse rounded-xl bg-[#0B5CFF]/10 dark:bg-gray-800"></div>
</div>
</div>
);
}

return (
<div className="space-y-6 bg-white min-h-screen p-6 transition-colors duration-300">
{/* 1. Welcome Card */}
<WelcomeCard displayName={displayName} />

{/* 2. Search Bar */}
<div className="w-full my-6">
<SearchBar />
</div>

{/* 3. Action Cards */}
<div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
<ActionCard
icon={Users}
title="Add Lead"
to="/leads/new"
color="bg-[#0B5CFF]"
hoverColor="bg-[#0B5CFF]/90"
steps={['New', 'Import', 'Assign']}
/>
<ActionCard
icon={Briefcase}
title="New Opportunity"
to="/opportunities/new"
color="bg-[#0B5CFF]"
hoverColor="bg-[#0B5CFF]/90"
steps={['Create', 'Assign', 'Track']}
/>
<ActionCard
icon={PhoneCall}
title="Log Activity"
to="/activities/new"
color="bg-[#0B5CFF]"
hoverColor="bg-[#0B5CFF]/90"
steps={['Call', 'Email', 'Task']}
/>
<ActionCard
icon={BarChart2}
title="Import Data"
to="/import"
color="bg-[#0B5CFF]"
hoverColor="bg-[#0B5CFF]/90"
steps={['Upload', 'Map', 'Import']}
/>
</div>

{/* 4. Stat Cards */}
<div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
<StatCard
title="Total Revenue"
value={`$${totalRevenue.toLocaleString()}`}
change={0}
icon={DollarSign}
color="bg-gradient-to-br from-[#0B5CFF] to-[#0B5CFF]/80"
/>
<StatCard
title="Leads"
value={leads.length}
change={0}
icon={Users}
color="bg-gradient-to-br from-[#0B5CFF] to-[#0B5CFF]/80"
/>
<StatCard
title="Accounts"
value={accounts.length}
change={0}
icon={Briefcase}
color="bg-gradient-to-br from-[#0B5CFF] to-[#0B5CFF]/80"
/>
<StatCard
title="Contacts"
value={contacts.length}
change={0}
icon={PhoneCall}
color="bg-gradient-to-br from-[#0B5CFF] to-[#0B5CFF]/80"
/>
<StatCard
title="Open Opportunities"
value={opportunities.filter(o => o.stage !== 'Closed Won' && o.stage !== 'Closed Lost').length}
change={0}
icon={TrendingUp}
color="bg-gradient-to-br from-[#0B5CFF] to-[#0B5CFF]/80"
/>
</div>

{/* 5. Pipeline Health & Goal Progress */}
<PipelineHealthCard
opportunityStages={opportunityStages}
opportunities={opportunities}
totalRevenue={totalRevenue}
/>

{/* 6. Opportunity Chart */}
<div className="rounded-xl border border-indigo-100 bg-white/70 backdrop-blur-md shadow-lg">
<OpportunityChart data={opportunityData} />
</div>

{/* 7. High-Scoring Leads & Recent Activity */}
<div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
<HighScoringLeadsCard leads={highScoringLeads} />
<RecentActivityCard activities={[]} />
</div>
</div>
);
};

export default Dashboard;
