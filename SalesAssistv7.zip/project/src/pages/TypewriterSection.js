// TypewriterSection.js
import React, { useEffect, useState } from "react";
import Typed from "react-typed";

const TypewriterSection = ({ label, content, isList, onDone, delay = 500 }) => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const timeout = setTimeout(() => setShow(true), delay);
    return () => clearTimeout(timeout);
  }, [delay]);

  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold text-black mb-2">{label}</h3>
      {show && (
        isList ? (
          <Typed
            strings={[content.join("\n")]}
            typeSpeed={24}
            showCursor={false}
            onComplete={onDone}
          >
            <ul className="list-disc pl-6 text-black">
              {content.map((item, idx) => (
                <li key={idx} className="mb-2">{item}</li>
              ))}
            </ul>
          </Typed>
        ) : (
          <Typed
            strings={[content]}
            typeSpeed={24}
            showCursor={false}
            onComplete={onDone}
          >
            <p className="text-black" />
          </Typed>
        )
      )}
    </div>
  );
};

export default TypewriterSection;
