import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useSalesforce } from '../context/SalesforceContext';
import { Users, Briefcase, User, Building, Mail, Phone, Calendar, ChevronRight, MessageSquare } from 'lucide-react';
import { GoogleGenerativeAI } from "@google/generative-ai";
import ReactMarkdown from "react-markdown";

// Vite env key
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

// Prompt for company info, contacts, and tech stack
const PROMPT_TEMPLATE = (company) => `
You are a business intelligence assistant.
For the company "${company}", provide the following sections in markdown:

## Company Information
A concise summary (2-3 sentences) about the company, including its industry, headquarters, and main products/services.

## Top 5 Contacts
List the top 5 senior executives or decision makers at the company, including their names, titles, and (if publicly available) LinkedIn URLs. If none found, provide 5 realistic dummy contacts for "${company}".

## Tech Stack, Products, and Services
Provide a detailed list of ${company}'s core products, cloud services, AI models, developer tools, and tech stack components as of 2025.
`;

// Parse Gemini response into sections
const parseGeminiResponse = (text) => {
  const sections = {
    info: "",
    contacts: [],
    tech: "",
  };
  let current = "";
  text.split("\n").forEach((line) => {
    if (line.startsWith("## Company Information")) current = "info";
    else if (line.startsWith("## Top 5 Contacts")) current = "contacts";
    else if (line.startsWith("## Tech Stack, Products, and Services")) current = "tech";
    else if (current === "info") sections.info += line + "\n";
    else if (current === "contacts" && line.trim().startsWith("-")) sections.contacts.push(line.trim().slice(1).trim());
    else if (current === "tech") sections.tech += line + "\n";
  });
  return sections;
};

// Generate dummy contacts for known companies
const getDummyContacts = (company) => {
  const lc = company.toLowerCase();
  if (lc === "amazon") {
    return [
      "Andy Jassy – Chief Executive Officer ([LinkedIn](https://www.linkedin.com/in/andyjassy))",
      "Adam Selipsky – CEO, Amazon Web Services ([LinkedIn](https://www.linkedin.com/in/adamselipsky))",
      "Brian Olsavsky – Chief Financial Officer ([LinkedIn](https://www.linkedin.com/in/brianolsavsky))",
      "Doug Herrington – CEO, Worldwide Amazon Stores ([LinkedIn](https://www.linkedin.com/in/dougherrington))",
      "Dave Limp – Senior Vice President, Devices & Services ([LinkedIn](https://www.linkedin.com/in/davelimp))"
    ];
  }
  if (lc === "google" || lc === "alphabet") {
    return [
      "Sundar Pichai – Chief Executive Officer ([LinkedIn](https://www.linkedin.com/in/sundarpichai))",
      "Thomas Kurian – CEO, Google Cloud ([LinkedIn](https://www.linkedin.com/in/thomaskurian))",
      "Ruth Porat – Chief Financial Officer ([LinkedIn](https://www.linkedin.com/in/ruthporat))",
      "Lorraine Twohill – Chief Marketing Officer ([LinkedIn](https://www.linkedin.com/in/lorrainetwohill))",
      "Demis Hassabis – CEO, Google DeepMind ([LinkedIn](https://www.linkedin.com/in/demishassabis))"
    ];
  }
  if (lc === "microsoft") {
    return [
      "Satya Nadella – Chief Executive Officer ([LinkedIn](https://www.linkedin.com/in/satyanadella))",
      "Amy Hood – Chief Financial Officer ([LinkedIn](https://www.linkedin.com/in/amyhood))",
      "Scott Guthrie – EVP, Cloud + AI Group ([LinkedIn](https://www.linkedin.com/in/scottgu))",
      "Kathleen Hogan – Chief Human Resources Officer ([LinkedIn](https://www.linkedin.com/in/kathleenhogan))",
      "Brad Smith – President and Vice Chair ([LinkedIn](https://www.linkedin.com/in/bradsmithmsft))"
    ];
  }
  // Fallback generic dummy contacts
  return [
    `${company} Executive 1 – Chief Executive Officer ([LinkedIn](#))`,
    `${company} Executive 2 – Chief Financial Officer ([LinkedIn](#))`,
    `${company} Executive 3 – Chief Technology Officer ([LinkedIn](#))`,
    `${company} Executive 4 – Chief Marketing Officer ([LinkedIn](#))`,
    `${company} Executive 5 – Chief Operations Officer ([LinkedIn](#))`
  ];
};

// Helper to check if query matches a person (lead/contact)
function findPerson(query, leads, contacts) {
  const q = query.toLowerCase().trim();
  // Try to match full name (exact match)
  const lead = leads.find(
    l => `${(l.firstName || '').toLowerCase()} ${(l.lastName || '').toLowerCase()}`.trim() === q
  );
  if (lead) return { type: "lead", data: lead };
  const contact = contacts.find(
    c => `${(c.firstName || '').toLowerCase()} ${(c.lastName || '').toLowerCase()}`.trim() === q
  );
  if (contact) return { type: "contact", data: contact };
  return null;
}

const SearchResults = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q')?.toLowerCase() || '';
  const displayCompany = query.charAt(0).toUpperCase() + query.slice(1);
  const { leads, accounts, contacts, opportunities } = useSalesforce();
  const [aiData, setAiData] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);

  // CRM filters (unchanged)
  const filteredLeads = leads.filter(lead => {
    const fullName = `${lead.firstName || ''} ${lead.lastName || ''}`.trim().toLowerCase();
    return (
      (lead.firstName && lead.firstName.toLowerCase().includes(query)) ||
      (lead.lastName && lead.lastName.toLowerCase().includes(query)) ||
      (lead.company && lead.company.toLowerCase().includes(query)) ||
      (lead.email && lead.email.toLowerCase().includes(query)) ||
      (lead.phone && lead.phone.toLowerCase().includes(query)) ||
      (lead.title && lead.title.toLowerCase().includes(query)) ||
      fullName.includes(query)
    );
  });

  const filteredContacts = contacts.filter(contact => {
    const fullName = `${contact.firstName || ''} ${contact.lastName || ''}`.trim().toLowerCase();
    return (
      (contact.firstName && contact.firstName.toLowerCase().includes(query)) ||
      (contact.lastName && contact.lastName.toLowerCase().includes(query)) ||
      (contact.email && contact.email.toLowerCase().includes(query)) ||
      (contact.phone && contact.phone.toLowerCase().includes(query)) ||
      (contact.title && contact.title.toLowerCase().includes(query)) ||
      fullName.includes(query)
    );
  });

  const filteredAccounts = accounts.filter(account =>
    (account.name && account.name.toLowerCase().includes(query)) ||
    (account.industry && account.industry.toLowerCase().includes(query)) ||
    (account.website && account.website.toLowerCase().includes(query)) ||
    (account.phone && account.phone.toLowerCase().includes(query)) ||
    (account.type && account.type.toLowerCase().includes(query)) ||
    (account.city && account.city.toLowerCase().includes(query)) ||
    (account.country && account.country.toLowerCase().includes(query))
  );

  const filteredOpportunities = opportunities.filter(opp =>
    (opp.name && opp.name.toLowerCase().includes(query)) ||
    (opp.accountName && opp.accountName.toLowerCase().includes(query)) ||
    (opp.stage && opp.stage.toLowerCase().includes(query)) ||
    (opp.amount && opp.amount.toString().includes(query)) ||
    (opp.type && opp.type.toLowerCase().includes(query))
  );

  const hasResults =
    filteredLeads.length > 0 ||
    filteredContacts.length > 0 ||
    filteredAccounts.length > 0 ||
    filteredOpportunities.length > 0;

  // Person match logic
  const personMatch = findPerson(query, leads, contacts);

  // Fetch Gemini AI insights (only if not a person)
  useEffect(() => {
    if (!query || personMatch) {
      setAiData(null);
      setAiLoading(false);
      return;
    }
    setAiLoading(true);

    const fetchGemini = async () => {
      try {
        const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const result = await model.generateContent(PROMPT_TEMPLATE(displayCompany));
        const text = await result.response.text();
        const parsed = parseGeminiResponse(text);
        // If no contacts found, use dummy contacts
        if (!parsed.contacts || parsed.contacts.length === 0) {
          parsed.contacts = getDummyContacts(displayCompany);
        }
        setAiData(parsed);
      } catch {
        setAiData({
          info: "Could not fetch data from Gemini API.",
          contacts: getDummyContacts(displayCompany),
          tech: "",
        });
      }
      setAiLoading(false);
    };

    fetchGemini();
    // eslint-disable-next-line
  }, [query, personMatch]);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <MessageSquare className="h-7 w-7 text-blue-600" />
        <h1 className="text-2xl font-bold text-black">
          Search Results for "{displayCompany}"
        </h1>
      </div>
      {/* Person (Lead/Contact) Info */}
      {personMatch && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-black mt-8">
          <h2 className="text-xl font-bold text-blue-700 mb-2">
            {personMatch.type === "lead" ? "Lead" : "Contact"} Information
          </h2>
          <ul className="mb-2">
            <li>
              <b>Name:</b> {personMatch.data.firstName} {personMatch.data.lastName}
            </li>
            {personMatch.data.email && (
              <li>
                <b>Email:</b> {personMatch.data.email}
              </li>
            )}
            {personMatch.data.phone && (
              <li>
                <b>Phone:</b> {personMatch.data.phone}
              </li>
            )}
            {personMatch.data.company && (
              <li>
                <b>Company:</b> {personMatch.data.company}
              </li>
            )}
            {personMatch.data.accountName && (
              <li>
                <b>Account:</b> {personMatch.data.accountName}
              </li>
            )}
            {personMatch.data.title && (
              <li>
                <b>Title:</b> {personMatch.data.title}
              </li>
            )}
            {/* Add more fields as needed */}
          </ul>
        </div>
      )}
      {/* Gemini AI Insights */}
      {!personMatch && (
        <div className="mt-8">
          <h2 className="text-xl font-bold text-blue-700 mb-2">Company Intelligence (Gemini AI)</h2>
          {aiLoading ? (
            <div className="text-black">Loading AI-powered insights...</div>
          ) : aiData ? (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-black">
              <h3 className="text-lg font-semibold text-black mb-2">Company Information</h3>
              <ReactMarkdown>{aiData.info?.trim() || "No company description available."}</ReactMarkdown>

              <h3 className="text-lg font-semibold text-black mb-2 mt-6">Top 5 Contacts</h3>
              <ul className="mb-6">
                {aiData.contacts.map((c, idx) => (
                  <li key={idx} className="mb-2 text-black">
                    <ReactMarkdown>{c}</ReactMarkdown>
                  </li>
                ))}
              </ul>

              <h3 className="text-lg font-semibold text-black mb-2">{displayCompany} Tech Stack, Products, and Services</h3>
              <ReactMarkdown>{aiData.tech?.trim() || "No tech stack information available."}</ReactMarkdown>
            </div>
          ) : null}
        </div>
      )}

      <div className="bg-white rounded-lg p-6 border border-blue-100">
        <div className="flex items-center gap-2 mb-2">
          <ChevronRight className="h-5 w-5 text-blue-600" />
          <h2 className="font-semibold text-black">Summary</h2>
        </div>
        <p className="text-black">
          {hasResults
            ? `We found ${filteredLeads.length} leads, ${filteredContacts.length} contacts, ${filteredAccounts.length} accounts, and ${filteredOpportunities.length} opportunities.`
            : `No results found for "${displayCompany}".`}
        </p>
      </div>
      {/* Leads */}
      {filteredLeads.length > 0 && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="p-6 border-b border-blue-100 flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-600" />
            <h2 className="text-lg font-semibold text-black">Leads</h2>
            <span className="text-sm text-black">{filteredLeads.length} found</span>
          </div>
          <div className="divide-y divide-blue-100">
            {filteredLeads.map(lead => (
              <div key={lead.id} className="p-6 hover:bg-blue-50 transition-colors">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-black">{lead.firstName} {lead.lastName}</h3>
                    <p className="text-black">{lead.company}</p>
                    <div className="flex gap-4 mt-2">
                      <span className="flex items-center gap-1 text-sm text-black">
                        <Mail className="h-4 w-4" /> {lead.email}
                      </span>
                      <span className="flex items-center gap-1 text-sm text-black">
                        <Phone className="h-4 w-4" /> {lead.phone}
                      </span>
                      <span className="flex items-center gap-1 text-sm text-black">
                        <Briefcase className="h-4 w-4" /> {lead.title}
                      </span>
                    </div>
                  </div>
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                    {lead.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Contacts */}
      {filteredContacts.length > 0 && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="p-6 border-b border-blue-100 flex items-center gap-2">
            <User className="h-5 w-5 text-blue-600" />
            <h2 className="text-lg font-semibold text-black">Contacts</h2>
            <span className="text-sm text-black">{filteredContacts.length} found</span>
          </div>
          <div className="divide-y divide-blue-100">
            {filteredContacts.map(contact => (
              <div key={contact.id} className="p-6 hover:bg-blue-50 transition-colors">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-black">{contact.firstName} {contact.lastName}</h3>
                    <div className="flex gap-4 mt-2">
                      <span className="flex items-center gap-1 text-sm text-black">
                        <Mail className="h-4 w-4" /> {contact.email}
                      </span>
                      <span className="flex items-center gap-1 text-sm text-black">
                        <Phone className="h-4 w-4" /> {contact.phone}
                      </span>
                      <span className="flex items-center gap-1 text-sm text-black">
                        <Briefcase className="h-4 w-4" /> {contact.title}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Accounts */}
      {filteredAccounts.length > 0 && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="p-6 border-b border-blue-100 flex items-center gap-2">
            <Building className="h-5 w-5 text-blue-600" />
            <h2 className="text-lg font-semibold text-black">Accounts</h2>
            <span className="text-sm text-black">{filteredAccounts.length} found</span>
          </div>
          <div className="divide-y divide-blue-100">
            {filteredAccounts.map(account => (
              <div key={account.id} className="p-6 hover:bg-blue-50 transition-colors">
                <div>
                  <h3 className="text-lg font-semibold text-black">{account.name}</h3>
                  <div className="flex gap-4 mt-2">
                    <span className="flex items-center gap-1 text-sm text-black">
                      <Phone className="h-4 w-4" /> {account.phone}
                    </span>
                    <span className="flex items-center gap-1 text-sm text-black">
                      <Briefcase className="h-4 w-4" /> {account.type}
                    </span>
                    <span className="flex items-center gap-1 text-sm text-black">
                      <Calendar className="h-4 w-4" /> {account.industry}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Opportunities */}
      {filteredOpportunities.length > 0 && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="p-6 border-b border-blue-100 flex items-center gap-2">
            <Briefcase className="h-5 w-5 text-blue-600" />
            <h2 className="text-lg font-semibold text-black">Opportunities</h2>
            <span className="text-sm text-black">{filteredOpportunities.length} found</span>
          </div>
          <div className="divide-y divide-blue-100">
            {filteredOpportunities.map(opp => (
              <div key={opp.id} className="p-6 hover:bg-blue-50 transition-colors">
                <div>
                  <h3 className="text-lg font-semibold text-black">{opp.name}</h3>
                  <div className="flex gap-4 mt-2">
                    <span className="flex items-center gap-1 text-sm text-black">
                      <Building className="h-4 w-4" /> {opp.accountName}
                    </span>
                    <span className="flex items-center gap-1 text-sm text-black">
                      <Briefcase className="h-4 w-4" /> {opp.stage}
                    </span>
                    <span className="flex items-center gap-1 text-sm text-black">
                      <Calendar className="h-4 w-4" /> {opp.closeDate}
                    </span>
                    <span className="flex items-center gap-1 text-sm text-black">
                      <Users className="h-4 w-4" /> Probability: {opp.probability}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* No Results */}
      {!hasResults && (
        <div className="text-center text-black py-12">
          No results found for "{displayCompany}".
        </div>
      )}
    </div>
  );
};

export default SearchResults;
