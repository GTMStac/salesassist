import React, { useState } from "react";
import { useSalesforce } from "../context/SalesforceContext";
import ObjectList from "../components/objects/ObjectList";
import { Briefcase, Calendar, DollarSign, BarChart, Tag } from "lucide-react";
import { Link } from "react-router-dom";

// Helper to encode chart config for QuickChart.io
const getDonutChartUrl = (labels, data, colors, width = 280, height = 280) => {
  const chartConfig = {
    type: 'doughnut',
    data: { labels, datasets: [{ data, backgroundColor: colors }] },
    options: { plugins: { legend: { display: false } } }
  };
  return `https://quickchart.io/chart?c=${encodeURIComponent(JSON.stringify(chartConfig))}&width=${width}&height=${height}`;
};

const countOpportunitiesByType = (opportunities = [], type) => opportunities.filter(opp => opp.type === type).length;
const countUpcomingRenewals = (opportunities = []) => opportunities.filter(opp => opp.type === "Renewal" && ["Qualification", "Proposal", "Negotiation"].includes(opp.stage)).length;
const countPotentialUpsells = (opportunities = []) => opportunities.filter(opp => opp.type === "Upsell" && ["Qualification", "Proposal", "Negotiation"].includes(opp.stage)).length;

const summaryCards = [
  {
    title: "Opportunity Types",
    subtitle: "Distribution of deals by type",
    getChartUrl: (opportunities = []) => getDonutChartUrl(
      ["New Business", "Renewals", "Upsell", "Cross-sell"],
      [
        countOpportunitiesByType(opportunities, "New Business"),
        countOpportunitiesByType(opportunities, "Renewal"),
        countOpportunitiesByType(opportunities, "Upsell"),
        countOpportunitiesByType(opportunities, "Cross-sell"),
      ],
      ["#2563eb", "#60a5fa", "#38bdf8", "#a5b4fc"]
    ),
    legend: [
      { label: "New Business", color: "bg-blue-600" },
      { label: "Renewals", color: "bg-blue-400" },
      { label: "Upsell", color: "bg-sky-400" },
      { label: "Cross-sell", color: "bg-indigo-200" },
    ],
    getCounts: (opportunities = []) => ({
      "New Business": countOpportunitiesByType(opportunities, "New Business"),
      "Renewals": countOpportunitiesByType(opportunities, "Renewal"),
      "Upsell": countOpportunitiesByType(opportunities, "Upsell"),
      "Cross-sell": countOpportunitiesByType(opportunities, "Cross-sell"),
    }),
  },
  {
    title: "Upcoming Renewals",
    subtitle: "Renewals due in the near future",
    getChartUrl: (opportunities = []) => getDonutChartUrl(
      ["This Month", "Next Month", "In 60 Days"],
      [countUpcomingRenewals(opportunities), 0, 0],
      ["#2563eb", "#60a5fa", "#a5b4fc"]
    ),
    legend: [
      { label: "This Month", color: "bg-blue-600" },
      { label: "Next Month", color: "bg-blue-400" },
      { label: "In 60 Days", color: "bg-indigo-200" },
    ],
    getCounts: (opportunities = []) => ({
      "This Month": countUpcomingRenewals(opportunities),
      "Next Month": 0,
      "In 60 Days": 0,
    }),
  },
  {
    title: "Potential Upsells",
    subtitle: "Opportunities for upselling (Value in $K)",
    getChartUrl: (opportunities = []) => getDonutChartUrl(
      ["High", "Medium", "Low"],
      [countPotentialUpsells(opportunities), 0, 0],
      ["#2563eb", "#60a5fa", "#a5b4fc"]
    ),
    legend: [
      { label: "High", color: "bg-blue-600" },
      { label: "Medium", color: "bg-blue-400" },
      { label: "Low", color: "bg-indigo-200" },
    ],
    getCounts: (opportunities = []) => ({
      "High": countPotentialUpsells(opportunities),
      "Medium": 0,
      "Low": 0,
    }),
  },
];

const tabs = ["All Deals", "My Deals", "Looked Deals", "Closing Deals"];
const STAGES = [
  { label: "Discovery", color: "bg-blue-100 text-blue-800" },
  { label: "Qualification", color: "bg-yellow-100 text-yellow-800" },
  { label: "Proposal", color: "bg-indigo-100 text-indigo-800" },
  { label: "Negotiation", color: "bg-amber-100 text-amber-800" },
  { label: "Closed Won", color: "bg-green-100 text-green-800" },
  { label: "Closed Lost", color: "bg-red-100 text-red-800" },
];

const Opportunities = () => {
  const { opportunities = [], loading, error } = useSalesforce();
  const [activeTab, setActiveTab] = useState(0);

  const columns = [
    {
      key: "name",
      title: "Deals Name",
      render: (opp) => (
        <Link
          to={`/opportunities/${opp.id}`}
          className="text-slate-700 font-medium hover:text-blue-600 transition-colors"
        >
          {opp.name}
        </Link>
      ),
    },
    {
      key: "value",
      title: "Deals Value",
      render: (opp) => (
        <span className="text-slate-600">{opp.value || opp.stage || "-"}</span>
      ),
    },
    {
      key: "accountName",
      title: "Name of Deals",
      render: (opp) => (
        <div className="flex items-center gap-2">
          <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-slate-100 text-slate-400 font-bold">
            {opp.ownerInitials || (
              <svg width="20" height="20"><circle cx="10" cy="10" r="10" fill="#e5e7eb" /></svg>
            )}
          </span>
          <span className="text-slate-700">{opp.accountName || opp.owner || "-"}</span>
        </div>
      ),
    },
    {
      key: "closeDate",
      title: "Closing Date",
      render: (opp) => (
        <span className="text-slate-600">
          {opp.closeDate
            ? new Date(opp.closeDate).toLocaleDateString()
            : "-"}
        </span>
      ),
    },
    {
      key: "amount",
      title: "Amount",
      render: (opp) => (
        <span className="text-slate-700 font-semibold">
          {opp.amount != null ? `$${opp.amount.toLocaleString()}` : "-"}
        </span>
      ),
    },
    {
      key: "stage",
      title: "Status",
      render: (opp) => {
        const stage = STAGES.find((s) => s.label === opp.stage) || STAGES[0];
        return (
          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${stage.color}`}>
            {opp.stage}
          </span>
        );
      },
    },
  ];

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
        <p className="text-red-700">
          Error loading opportunities: {error}
        </p>
      </div>
    );
  }

  return (
    <div className="bg-[#f6f8fa] min-h-screen p-8">
      {/* Top summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {summaryCards.map((card, idx) => {
          const chartUrl = card.getChartUrl(opportunities);
          const counts = card.getCounts(opportunities);
          return (
            <div
              key={idx}
              className="bg-white rounded-xl shadow border border-gray-100 p-6 flex flex-col items-center"
            >
              <div className="text-lg font-semibold text-slate-800 mb-1">
                {card.title}
              </div>
              <div className="text-xs text-slate-400 mb-3">
                {card.subtitle}
              </div>
              <img
                src={chartUrl}
                alt={`${card.title} Chart`}
                className="h-60 w-60 mx-auto"
              />
              <div className="flex flex-wrap gap-3 mt-4 justify-center">
                {card.legend.map((item, i) => (
                  <div key={i} className="flex items-center gap-1 text-xs">
                    <span className={`inline-block w-3 h-3 rounded-full ${item.color}`} />
                    <span className="font-medium text-slate-600">{item.label}</span>
                    <span className="text-slate-400">{counts[item.label] || 0}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Deals Management */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <div className="text-2xl font-bold text-slate-800 mb-1">
            Deals Management
          </div>
          <div className="text-sm text-slate-400">
            Optimizing, tracking, and closing deals
          </div>
        </div>
        <div className="flex gap-2">
          <button className="bg-blue-600 text-white font-semibold px-5 py-2 rounded-lg flex items-center gap-2 shadow hover:bg-blue-700 transition">
            + Create Deals
          </button>
          <button className="border border-gray-200 px-4 py-2 rounded-lg font-medium text-slate-700 bg-white flex items-center gap-2">
            Action
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-4 border-b border-gray-200">
        {tabs.map((tab, idx) => (
          <button
            key={tab}
            onClick={() => setActiveTab(idx)}
            className={`px-5 py-2 font-semibold text-base rounded-t-lg transition
              ${activeTab === idx
                ? "bg-blue-50 text-blue-700 border-b-2 border-blue-600"
                : "bg-transparent text-gray-400"
              }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Table (ObjectList) */}
      <div className="bg-white rounded-xl shadow border border-gray-100">
        <ObjectList
          title={null}
          data={opportunities}
          columns={columns}
          basePath="/opportunities"
          isLoading={loading}
        />
        {/* Footer Pagination */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-50 rounded-b-xl text-slate-500 text-sm">
          <div>Result 1-10 of {opportunities?.length ?? 0}</div>
          <div className="flex items-center gap-1">
            <button className="px-2 py-1 rounded hover:bg-blue-50">1</button>
            <button className="px-2 py-1 rounded hover:bg-blue-50">2</button>
            <button className="px-2 py-1 rounded hover:bg-blue-50">...</button>
            <button className="px-2 py-1 rounded hover:bg-blue-50">14</button>
            <select className="ml-2 px-2 py-1 rounded border border-gray-200">
              <option>10</option>
              <option>20</option>
              <option>50</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Opportunities;
