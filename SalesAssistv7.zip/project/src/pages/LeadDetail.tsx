import React, { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useSalesforce } from "../context/SalesforceContext";
import {
  Mail, Phone, ArrowLeft, ExternalLink, Activity, StickyNote, MailOpen,
  PhoneCall, CheckSquare, Calendar, User, Star, Bell, FileText
} from "lucide-react";

const tabDefs = [
  { key: "activity", label: "All Activity", icon: Activity },
  { key: "emails", label: "Emails", icon: MailOpen },
  { key: "calls", label: "Calls", icon: PhoneCall },
  { key: "tasks", label: "Tasks", icon: CheckSquare },
  { key: "events", label: "Meetings", icon: Calendar },
];

const activityTypes = [
  { label: "Activity", icon: Activity },
  { label: "Notes", icon: StickyNote },
  { label: "Emails", icon: MailOpen },
  { label: "Calls", icon: PhoneCall },
  { label: "Task", icon: CheckSquare },
  { label: "Meetings", icon: Calendar },
];

const LeadDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { getObjectById, activities, calls, emails, tasks, events } = useSalesforce();
  const lead = getObjectById("leads", id);

  // Tab state hooks
  const [tab, setTab] = useState("activity");
  const [leftTab, setLeftTab] = useState("leadInfo");
  const [mainTab, setMainTab] = useState("overview");
  const [activityType, setActivityType] = useState("Activity");

  if (!lead) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500">
        Lead not found.
      </div>
    );
  }

  // Filter activities for this lead
  const relatedActivities = activities.filter(
    a => a.whoId === lead.id || a.whatId === lead.id
  );
  const relatedCalls = calls.filter(
    a => a.whoId === lead.id || a.whatId === lead.id
  );
  const relatedEmails = emails.filter(
    a => a.whoId === lead.id || a.whatId === lead.id
  );
  const relatedTasks = tasks.filter(
    a => a.whoId === lead.id || a.whatId === lead.id
  );
  const relatedEvents = events.filter(
    e => e.whoId === lead.id || e.whatId === lead.id
  );

  const qualification = {
    label: "Hot",
    color: "bg-green-100 text-green-700",
    score: 87,
    explanation: "High engagement and recent activity",
  };

  const files = [
    { name: "Proposal.pdf", url: "#", uploaded: "2025-06-01" },
    { name: "NDA.docx", url: "#", uploaded: "2025-05-22" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-blue-100 p-2 sm:p-4 md:p-6 font-sans">
      {/* Sticky Action Bar */}
      <div className="sticky top-0 z-20 bg-white/90 backdrop-blur flex flex-col sm:flex-row flex-wrap items-center justify-between px-4 py-3 sm:px-6 sm:py-4 border-b shadow-sm">
        <div className="flex items-center gap-3 sm:gap-4 mb-2 sm:mb-0">
          <div className="bg-gradient-to-tr from-blue-500 to-indigo-500 rounded-full w-12 h-12 sm:w-14 sm:h-14 flex items-center justify-center text-white text-xl sm:text-2xl font-bold shadow-md">
            <User className="w-6 h-6 sm:w-8 sm:h-8" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-1 sm:gap-2">
              <span className="text-lg sm:text-xl md:text-2xl font-bold text-gray-900">
                {lead.firstName} {lead.lastName}
              </span>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold">
                {lead.title}
              </span>
              <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${qualification.color}`}>
                <Star className="h-3 w-3 sm:h-4 sm:w-4 inline mr-1" /> {qualification.label} ({qualification.score})
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-500">
              <Mail className="h-3 w-3 sm:h-4 sm:w-4" />
              <span>{lead.email}</span>
              <Phone className="h-3 w-3 sm:h-4 sm:w-4 ml-2 sm:ml-4" />
              <span>{lead.phone}</span>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-1 sm:gap-2">
          <a
            href={`https://login.salesforce.com/${lead.id}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 sm:gap-2 rounded-md bg-gradient-to-br from-blue-600 to-indigo-600 text-white font-semibold px-3 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm hover:shadow-lg transition"
          >
            <img
              src="https://cdn.worldvectorlogo.com/logos/salesforce-2.svg"
              alt="Salesforce"
              className="h-4 w-4 sm:h-5 sm:w-5"
            />
            <span className="hidden sm:inline">View in Salesforce</span>
            <ExternalLink className="h-3 w-3 sm:h-4 sm:w-4" />
          </a>
          <button className="rounded-md bg-yellow-50 px-3 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm font-medium text-yellow-700 hover:bg-yellow-100 transition flex items-center gap-1">
            <Bell className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="hidden sm:inline">Reminder</span>
          </button>
          {["Notes", "Email", "Call", "Task"].map((action) => (
            <button
              key={action}
              className="rounded-md bg-gray-100 px-3 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm font-medium text-gray-700 hover:bg-gray-200 transition"
            >
              <span className="hidden sm:inline">{action}</span>
              <span className="sm:hidden">
                {action === "Email" ? <MailOpen className="h-3 w-3" /> : null}
                {action === "Call" ? <PhoneCall className="h-3 w-3" /> : null}
                {action === "Notes" ? <StickyNote className="h-3 w-3" /> : null}
                {action === "Task" ? <CheckSquare className="h-3 w-3" /> : null}
              </span>
            </button>
          ))}
        </div>
      </div>
      {/* Responsive 3-column layout */}
      <div className="w-full max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6 pt-4 sm:pt-8">
        {/* Left Sidebar */}
        <aside className="lg:col-span-3 flex flex-col gap-4 sm:gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 sm:p-6">
            <Link to="/leads" className="text-blue-700 font-medium flex items-center gap-1 mb-3 sm:mb-4 hover:underline">
              <ArrowLeft className="h-4 w-4" /> <span className="hidden sm:inline">Back to leads</span>
            </Link>
            <div className="flex gap-2 mb-3 sm:mb-4">
              <button
                onClick={() => setLeftTab("leadInfo")}
                className={`px-2 py-1 sm:px-3 sm:py-1.5 rounded-lg text-xs sm:text-sm font-semibold shadow-sm transition ${
                  leftTab === "leadInfo" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-500"
                }`}
              >
                About Lead
              </button>
              <button
                onClick={() => setLeftTab("addressInfo")}
                className={`px-2 py-1 sm:px-3 sm:py-1.5 rounded-lg text-xs sm:text-sm font-semibold shadow-sm transition ${
                  leftTab === "addressInfo" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-500"
                }`}
              >
                Address Info
              </button>
            </div>
            {leftTab === "leadInfo" && (
              <div className="text-xs sm:text-sm text-gray-700 space-y-1 sm:space-y-2">
                <div><span className="font-semibold">Email:</span> {lead.email}</div>
                <div><span className="font-semibold">Phone:</span> {lead.phone}</div>
                <div><span className="font-semibold">Job title:</span> {lead.title}</div>
                <div><span className="font-semibold">Contact owner:</span> {lead.email}</div>
                <div><span className="font-semibold">Last contacted:</span> -</div>
                <div><span className="font-semibold">Company:</span> {lead.company}</div>
                <div><span className="font-semibold">Relationship:</span> {lead.relationship || "-"}</div>
              </div>
            )}
            {leftTab === "addressInfo" && (
              <div className="text-xs sm:text-sm text-gray-700">
                <div><span className="font-semibold">Street:</span> {lead.street || "-"}</div>
                <div><span className="font-semibold">City:</span> {lead.city || "-"}</div>
                <div><span className="font-semibold">State:</span> {lead.state || "-"}</div>
                <div><span className="font-semibold">Country:</span> {lead.country || "-"}</div>
                <div><span className="font-semibold">Postal Code:</span> {lead.postalCode || "-"}</div>
              </div>
            )}
          </div>
          {/* Files Section */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 sm:p-6">
            <h3 className="font-semibold mb-2 text-gray-800 flex items-center">
              <FileText className="h-4 w-4 sm:h-5 sm:w-5 mr-2" /> <span>Files</span>
            </h3>
            <ul className="space-y-2">
              {files.map((file) => (
                <li key={file.name} className="flex items-center justify-between text-xs sm:text-sm">
                  <a href={file.url} className="text-blue-700 hover:underline">{file.name}</a>
                  <span className="text-xs text-gray-400">{file.uploaded}</span>
                </li>
              ))}
            </ul>
            <button className="mt-3 px-2 py-1 sm:px-3 sm:py-1 bg-blue-50 text-blue-700 rounded hover:bg-blue-100 text-xs sm:text-sm font-medium">
              Upload File
            </button>
          </div>
        </aside>
        {/* Main Content */}
        <main className="lg:col-span-6 flex flex-col gap-4 sm:gap-6">
          <div className="flex gap-2 border-b pb-2">
            <button
              onClick={() => setMainTab("overview")}
              className={`px-3 py-1 sm:px-4 sm:py-2 rounded-t-lg font-semibold text-sm sm:text-base transition ${
                mainTab === "overview" ? "bg-blue-600 text-white" : "text-gray-600 hover:text-blue-700"
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setMainTab("activities")}
              className={`px-3 py-1 sm:px-4 sm:py-2 rounded-t-lg font-semibold text-sm sm:text-base transition ${
                mainTab === "activities" ? "bg-blue-600 text-white" : "text-gray-600 hover:text-blue-700"
              }`}
            >
              Activities
            </button>
          </div>
          {mainTab === "overview" && (
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 sm:p-6 md:p-8">
              <h3 className="font-semibold text-gray-800 mb-2 sm:mb-4">Overview</h3>
              <p className="text-gray-700 text-sm sm:text-base">
                This lead is a key contact at {lead.company} and has shown interest in our marketing solutions.
              </p>
              <div className="mt-4 sm:mt-6 flex flex-wrap gap-2 sm:gap-4">
                <div className="bg-green-50 text-green-700 px-3 py-1 sm:px-4 sm:py-2 rounded-lg font-semibold text-xs sm:text-sm flex items-center gap-1 sm:gap-2">
                  <Star className="h-3 w-3 sm:h-4 sm:w-4" /> Lead Score: {qualification.score}
                </div>
                <div className="bg-blue-50 text-blue-700 px-3 py-1 sm:px-4 sm:py-2 rounded-lg font-semibold text-xs sm:text-sm flex items-center gap-1 sm:gap-2">
                  <Bell className="h-3 w-3 sm:h-4 sm:w-4" /> Next Action: Schedule follow-up call
                </div>
              </div>
            </div>
          )}
          {mainTab === "activities" && (
            <>
              <input
                type="text"
                className="w-full border border-gray-200 rounded-lg px-3 py-2 mb-2 sm:mb-4 bg-gray-50 text-sm sm:text-base"
                placeholder="Search activity, notes, email and more..."
              />
              <div className="flex gap-1 sm:gap-2 mb-3 sm:mb-4 flex-wrap">
                {activityTypes.map(({ icon: IconComp, label }) => (
                  <button
                    key={label}
                    type="button"
                    onClick={() => setActivityType(label)}
                    className={`flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-1 rounded-lg text-xs sm:text-sm font-medium transition ${
                      activityType === label
                        ? "bg-blue-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-blue-50"
                    }`}
                  >
                    <IconComp className="h-3 w-3 sm:h-4 sm:w-4" /> <span className="hidden sm:inline">{label}</span>
                    <span className="sm:hidden">{label === "Notes" ? "N" : label === "Emails" ? "E" : label === "Calls" ? "C" : label === "Task" ? "T" : label === "Meetings" ? "M" : "A"}</span>
                  </button>
                ))}
              </div>
              <div className="bg-white border border-gray-100 rounded-xl p-3 sm:p-4 md:p-6 mb-4 sm:mb-6 shadow-sm min-h-[120px] flex items-center">
                {/* Activity creation forms can go here */}
                {activityType === "Notes" && <div className="w-full">Add new note form here.</div>}
                {activityType === "Emails" && <div className="w-full">Email composer or email activity here.</div>}
                {activityType === "Calls" && <div className="w-full">Call log or call notes here.</div>}
                {activityType === "Task" && <div className="w-full">Task creation form here.</div>}
                {activityType === "Meetings" && <div className="w-full">Meeting notes or event form here.</div>}
                {activityType === "Activity" && <div className="w-full">Show all activities here.</div>}
              </div>
              {/* Timeline */}
              <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-3 sm:p-4 md:p-6">
                <div className="mb-2 text-gray-500 text-xs sm:text-sm">Recent Activities</div>
                {activityType === "Activity" &&
                  relatedActivities.map((a) => (
                    <div key={a.id} className="mb-3">
                      <div className="text-xs text-gray-400">
                        <span className="font-semibold">{a.subject}</span> {a.type || a.taskSubtype}
                      </div>
                      <div className="text-gray-700 text-sm">{a.description}</div>
                    </div>
                  ))}
                {activityType === "Calls" &&
                  relatedCalls.map((c) => (
                    <div key={c.id} className="mb-3">
                      <div className="text-xs text-gray-400">
                        <span className="font-semibold">{c.subject}</span> {c.type || c.taskSubtype}
                      </div>
                      <div className="text-gray-700 text-sm">{c.description}</div>
                    </div>
                  ))}
                {activityType === "Emails" &&
                  relatedEmails.map((e) => (
                    <div key={e.id} className="mb-3">
                      <div className="text-xs text-gray-400">
                        <span className="font-semibold">{e.subject}</span> {e.type || e.taskSubtype}
                      </div>
                      <div className="text-gray-700 text-sm">{e.description}</div>
                    </div>
                  ))}
                {activityType === "Task" &&
                  relatedTasks.map((t) => (
                    <div key={t.id} className="mb-3">
                      <div className="text-xs text-gray-400">
                        <span className="font-semibold">{t.subject}</span> {t.type || t.taskSubtype}
                      </div>
                      <div className="text-gray-700 text-sm">{t.description}</div>
                    </div>
                  ))}
                {activityType === "Meetings" &&
                  relatedEvents.map((ev) => (
                    <div key={ev.id} className="mb-3">
                      <div className="text-xs text-gray-400">
                        <span className="font-semibold">{ev.subject}</span> Meeting
                      </div>
                      <div className="text-gray-700 text-sm">{ev.description}</div>
                      <div className="text-xs text-gray-400">{ev.startDateTime} - {ev.endDateTime}</div>
                    </div>
                  ))}
                {activityType === "Notes" && (
                  <div className="text-gray-500 text-xs">No notes yet.</div>
                )}
              </div>
            </>
          )}
        </main>
        {/* Right Sidebar */}
        <aside className="lg:col-span-3 flex flex-col gap-4 sm:gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 sm:p-6">
            <h3 className="font-semibold mb-2 text-gray-800">Company Details</h3>
            <div className="text-xs sm:text-sm text-gray-700">
              <div className="mb-2"><span className="font-semibold">Company:</span> {lead.company}</div>
              <div className="mb-2"><span className="font-semibold">Industry:</span> {lead.industry || "-"}</div>
              <div className="mb-2"><span className="font-semibold">Website:</span> {lead.website || "-"}</div>
              <div className="mb-2"><span className="font-semibold">Phone:</span> {lead.companyPhone || lead.phone || "-"}</div>
              <div className="mb-2"><span className="font-semibold">Type:</span> {lead.type || "-"}</div>
              <div className="mb-2"><span className="font-semibold">City:</span> {lead.city || "-"}</div>
              <div><span className="font-semibold">Country:</span> {lead.country || "-"}</div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 sm:p-6">
            <h3 className="font-semibold mb-2 text-gray-800">AI-Generated Insights</h3>
            <div className="text-xs sm:text-sm text-gray-700">
              <div className="mb-2">
                <span className="font-semibold">Recent News:</span>
                <span className="italic text-gray-400 ml-2">{lead.aiInsights?.news || "No recent news"}</span>
              </div>
              <div className="mb-2">
                <span className="font-semibold">Potential Pain Points</span>
                <ul className="list-disc ml-6">
                  {(lead.aiInsights?.painPoints || []).map((p: string, i: number) => (
                    <li key={i}>{p}</li>
                  ))}
                </ul>
              </div>
              <div>
                <span className="font-semibold">Conversation Intelligence:</span>
                <span className="italic text-gray-400 ml-2">{lead.aiInsights?.intelligence || "No data"}</span>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default LeadDetail;
