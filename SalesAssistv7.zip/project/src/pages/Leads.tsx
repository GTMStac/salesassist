import React, { useState, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { useSalesforce } from '../context/SalesforceContext';
import ObjectList from '../components/objects/ObjectList';
import { Mail, Phone, Users, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const PAGE_SIZE = 10;

const Leads = () => {
  const { leads, loading, addLead } = useSalesforce();
  const instanceUrl = localStorage.getItem('sf_instance_url') || 'https://login.salesforce.com';

  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [syncToSF, setSyncToSF] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [localLeads, setLocalLeads] = useState<any[]>([]);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);

  // React Hook Form setup
  const { register, handleSubmit, formState: { errors }, reset } = useForm({
    defaultValues: {
      firstName: '',
      lastName: '',
      company: '',
      phone: '',
      email: '',
      title: '',
      status: 'New',
    }
  });

  // Combine Salesforce and local leads (for "not synced" leads)
  const allLeads = useMemo(() => [...localLeads, ...leads], [localLeads, leads]);

  // Filter leads by search term
  const filteredLeads = useMemo(() => {
    if (!searchTerm) return allLeads;
    const term = searchTerm.toLowerCase();
    return allLeads.filter(lead =>
      [lead.firstName, lead.lastName, lead.company, lead.email, lead.phone, lead.title]
        .filter(Boolean)
        .some(val => val.toLowerCase().includes(term))
    );
  }, [allLeads, searchTerm]);

  // Pagination logic
  const totalPages = Math.ceil(filteredLeads.length / PAGE_SIZE) || 1;
  const paginatedLeads = filteredLeads.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const onSubmit = async (data: any) => {
    setSaving(true);
    setFormError(null);
    setInfoMessage(null);
    try {
      if (syncToSF) {
        await addLead(data);
        setInfoMessage('Lead synced! It will appear after the next refresh.');
      } else {
        setLocalLeads([
          {
            ...data,
            id: `local-${Date.now()}`,
            status: data.status || 'New',
          },
          ...localLeads
        ]);
      }
      setShowForm(false);
      reset();
      setCurrentPage(1);
    } catch (err: any) {
      setFormError(err.message || 'Failed to add lead');
    }
    setSaving(false);
  };

  const columns = [
    {
      key: 'name',
      title: 'Name',
      render: (lead: any) => (
        <Link
          to={`/leads/${lead.id}`}
          className="font-medium text-slate-900 hover:text-blue-600 transition-colors"
        >
          {lead.firstName} {lead.lastName}
        </Link>
      ),
    },
    {
      key: 'salesforceLink',
      title: '',
      render: (lead: any) =>
        lead.id && !lead.id.startsWith('local-') ? (
          <a
            href={`${instanceUrl}/${lead.id}`}
            target="_blank"
            rel="noopener noreferrer"
            title="Open in Salesforce"
            className="inline-flex items-center hover:opacity-80 transition-opacity"
          >
            <img
              src="https://cdn.worldvectorlogo.com/logos/salesforce-2.svg"
              alt="Salesforce"
              className="h-5 w-5"
            />
          </a>
        ) : null,
    },
    {
      key: 'company',
      title: 'Company',
      render: (lead: any) => (
        <span className="text-slate-700">{lead.company}</span>
      ),
    },
    {
      key: 'title',
      title: 'Title',
      render: (lead: any) => (
        <span className="text-slate-600">{lead.title}</span>
      ),
    },
    {
      key: 'email',
      title: 'Email',
      render: (lead: any) => (
        <div className="flex items-center">
          <Mail className="mr-2 h-4 w-4 text-indigo-400" />
          <span className="text-slate-600">{lead.email}</span>
        </div>
      ),
    },
    {
      key: 'phone',
      title: 'Phone',
      render: (lead: any) => (
        <div className="flex items-center">
          <Phone className="mr-2 h-4 w-4 text-green-400" />
          <span className="text-slate-600">{lead.phone}</span>
        </div>
      ),
    },
    {
      key: 'status',
      title: 'Status',
      render: (lead: any) => {
        let bgColor = 'bg-slate-100 text-slate-800';
        switch (lead.status) {
          case 'New':
            bgColor = 'bg-blue-100 text-blue-800';
            break;
          case 'Working':
            bgColor = 'bg-amber-100 text-amber-800';
            break;
          case 'Qualified':
            bgColor = 'bg-green-100 text-green-800';
            break;
          case 'Unqualified':
            bgColor = 'bg-red-100 text-red-800';
            break;
        }
        return (
          <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${bgColor}`}>
            {lead.status}
          </span>
        );
      },
    },
    {
      key: 'actions',
      title: '',
      render: (lead: any) => (
        <button className="p-1 rounded-full hover:bg-slate-100 transition-colors group">
          <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-blue-500" />
        </button>
      ),
    },
  ];

  return (
    <div className="space-y-6 p-6 bg-gradient-to-br from-blue-50/50 to-indigo-50/50 min-h-screen">
      <div className="flex items-center justify-between p-6 rounded-xl bg-white/70 backdrop-blur-sm shadow-lg border border-indigo-100">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Leads</h1>
          <p className="text-slate-500 mt-1">Manage and track your sales leads</p>
        </div>
        <button
          className="inline-flex items-center rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 px-6 py-3 text-sm font-medium text-white hover:shadow-lg hover:from-blue-700 hover:to-indigo-700 transition-all"
          onClick={() => setShowForm(true)}
        >
          <Users className="mr-2 h-4 w-4" />
          Add New Lead
        </button>
      </div>

      {/* Info message */}
      {infoMessage && (
        <div className="mb-4 text-blue-700 bg-blue-100 border border-blue-200 rounded px-4 py-2">
          {infoMessage}
        </div>
      )}

      {/* Search Bar */}
      <div className="mb-4 flex">
        <input
          type="text"
          placeholder="Search leads..."
          className="w-full border rounded px-4 py-2"
          value={searchTerm}
          onChange={e => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
        />
      </div>

      {/* Modal Form */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
          <div className="bg-white rounded-xl p-6 shadow-xl w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add New Lead</h2>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block mb-1 font-medium">First Name</label>
                  <input
                    {...register('firstName', { required: 'First name required' })}
                    className={`w-full border rounded px-3 py-2 ${errors.firstName ? 'border-red-500' : ''}`}
                  />
                  {errors.firstName && <span className="text-red-500 text-xs">{errors.firstName.message}</span>}
                </div>
                <div className="flex-1">
                  <label className="block mb-1 font-medium">Last Name</label>
                  <input
                    {...register('lastName', { required: 'Last name required' })}
                    className={`w-full border rounded px-3 py-2 ${errors.lastName ? 'border-red-500' : ''}`}
                  />
                  {errors.lastName && <span className="text-red-500 text-xs">{errors.lastName.message}</span>}
                </div>
              </div>
              <div>
                <label className="block mb-1 font-medium">Company</label>
                <input
                  {...register('company', { required: 'Company required' })}
                  className={`w-full border rounded px-3 py-2 ${errors.company ? 'border-red-500' : ''}`}
                />
                {errors.company && <span className="text-red-500 text-xs">{errors.company.message}</span>}
              </div>
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block mb-1 font-medium">Phone</label>
                  <input
                    {...register('phone')}
                    className="w-full border rounded px-3 py-2"
                  />
                </div>
                <div className="flex-1">
                  <label className="block mb-1 font-medium">Email</label>
                  <input
                    {...register('email', { pattern: { value: /\S+@\S+\.\S+/, message: 'Invalid email' } })}
                    className={`w-full border rounded px-3 py-2 ${errors.email ? 'border-red-500' : ''}`}
                  />
                  {errors.email && <span className="text-red-500 text-xs">{errors.email.message}</span>}
                </div>
              </div>
              <div>
                <label className="block mb-1 font-medium">Title</label>
                <input
                  {...register('title')}
                  className="w-full border rounded px-3 py-2"
                />
              </div>
              <div>
                <label className="block mb-1 font-medium">Status</label>
                <select
                  {...register('status')}
                  className="w-full border rounded px-3 py-2"
                >
                  <option value="New">New</option>
                  <option value="Working">Working</option>
                  <option value="Qualified">Qualified</option>
                  <option value="Unqualified">Unqualified</option>
                </select>
              </div>
              <div className="flex items-center mt-2">
                <input
                  type="checkbox"
                  id="syncToSF"
                  checked={syncToSF}
                  onChange={e => setSyncToSF(e.target.checked)}
                  className="mr-2"
                />
                <label htmlFor="syncToSF" className="font-medium">Sync to Salesforce</label>
              </div>
              {formError && <div className="text-red-500 text-sm">{formError}</div>}
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  className="px-4 py-2 rounded bg-slate-100 text-slate-700"
                  onClick={() => setShowForm(false)}
                  disabled={saving}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded bg-blue-600 text-white"
                  disabled={saving}
                >
                  {saving ? 'Saving...' : 'Save Lead'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ObjectList
        title="Leads"
        data={paginatedLeads}
        columns={columns}
        basePath="/leads"
        isLoading={loading}
        className="rounded-xl bg-white/70 backdrop-blur-sm shadow-lg border border-indigo-100 overflow-hidden"
        rowClassName="hover:bg-indigo-50/50 transition-colors group"
      />

      {/* Pagination Controls */}
      <div className="flex justify-center mt-6 gap-2">
        {Array.from({ length: totalPages }, (_, i) => (
          <button
            key={i + 1}
            className={`px-3 py-1 rounded ${currentPage === i + 1 ? 'bg-blue-600 text-white' : 'bg-white border'}`}
            onClick={() => setCurrentPage(i + 1)}
          >
            {i + 1}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Leads;
