import React from "react";
import { useSalesforce } from "../context/SalesforceContext";
import ObjectList from "../components/objects/ObjectList";
import { Mail, Phone, User, Briefcase } from "lucide-react";
import { Link } from "react-router-dom";

const Contacts = () => {
  const { contacts = [], loading } = useSalesforce();

  const columns = [
    {
      key: "lastName",
      title: "Name",
      render: (contact: any) => (
        <Link
          to={`/contacts/${contact.id}`}
          className="flex items-center group"
        >
          <div className="mr-3 flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-tr from-blue-500 to-indigo-500 text-white font-bold shadow-md">
            <span>
              {contact.firstName?.[0] ?? ""}
              {contact.lastName?.[0] ?? ""}
            </span>
          </div>
          <span className="font-medium text-slate-900 group-hover:text-blue-600 transition-colors">
            {contact.firstName} {contact.lastName}
          </span>
        </Link>
      ),
    },
    {
      key: "title",
      title: "Title",
      render: (contact: any) => (
        <div className="flex items-center">
          <User className="mr-2 h-4 w-4 text-slate-400" />
          <span>{contact.title}</span>
        </div>
      ),
    },
    {
      key: "accountId",
      title: "Account",
      render: (contact: any) => (
        <div className="flex items-center">
          <Briefcase className="mr-2 h-4 w-4 text-slate-400" />
          <span>{contact.accountId}</span>
        </div>
      ),
    },
    {
      key: "email",
      title: "Email",
      render: (contact: any) => (
        <div className="flex items-center">
          <Mail className="mr-2 h-4 w-4 text-slate-400" />
          <span>{contact.email}</span>
        </div>
      ),
    },
    {
      key: "phone",
      title: "Phone",
      render: (contact: any) => (
        <div className="flex items-center">
          <Phone className="mr-2 h-4 w-4 text-slate-400" />
          <span>{contact.phone}</span>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50/50 to-indigo-50/50 p-6 font-sans">
      {/* Hero/Banner Section */}
      <div className="flex flex-col sm:flex-row items-center justify-between p-6 bg-white/80 backdrop-blur-sm rounded-xl shadow-lg border border-indigo-100 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Contacts</h1>
          <p className="text-slate-500 mt-1">Manage your customer and prospect contacts</p>
        </div>
        <button className="inline-flex items-center rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 px-6 py-3 text-sm font-medium text-white hover:shadow-lg hover:from-blue-700 hover:to-indigo-700 transition-all">
          <User className="mr-2 h-4 w-4" />
          Add New Contact
        </button>
      </div>

      {/* Table Section */}
      <div className="rounded-xl bg-white/80 backdrop-blur-sm shadow-lg border border-indigo-100 overflow-hidden">
        <ObjectList
          title="Contacts"
          data={contacts}
          columns={columns}
          basePath="/contacts"
          isLoading={loading}
          className="rounded-xl bg-white/80 backdrop-blur-sm shadow-lg border border-indigo-100 overflow-hidden"
          rowClassName="hover:bg-indigo-50/50 transition-colors group"
        />
      </div>
    </div>
  );
};

export default Contacts;
