import React from 'react';
import { useSalesforce } from '../context/SalesforceContext';
import { Briefcase, DollarSign, Calendar, User, Tag, Plus } from 'lucide-react';

const OpportunityPipeline = () => {
  // Use real Salesforce data
  const { opportunities, stages, loading } = useSalesforce();

  // Handle loading and undefined data safely
  if (
    loading ||
    !Array.isArray(stages) ||
    !Array.isArray(opportunities)
  ) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  // Group opportunities by stage label
  const grouped = stages.reduce((acc, stage) => {
    acc[stage.label] = opportunities.filter(opp => opp.stage === stage.label);
    return acc;
  }, {} as Record<string, any[]>);

  const totalValue = opportunities.reduce((sum, opp) => sum + (opp.amount || 0), 0);
  const avgDealSize = opportunities.length > 0 ? totalValue / opportunities.length : 0;
  const winRate =
    opportunities.length > 0
      ? (opportunities.filter(opp => opp.stage === 'Closed Won').length / opportunities.length) * 100
      : 0;

  return (
    <div className="space-y-6 p-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Pipeline Overview</h1>
          <p className="text-slate-500 text-sm">Track and manage your sales pipeline</p>
        </div>
        <button className="inline-flex items-center rounded-md bg-primary-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-primary-700 transition-colors">
          <Plus className="mr-1 h-4 w-4" /> Add Opportunity
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-3">
          <h3 className="text-sm font-medium text-slate-500">Total Pipeline Value</h3>
          <p className="text-xl font-bold text-slate-900">${totalValue.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg shadow p-3">
          <h3 className="text-sm font-medium text-slate-500">Average Deal Size</h3>
          <p className="text-xl font-bold text-slate-900">${avgDealSize.toLocaleString(undefined, {maximumFractionDigits: 0})}</p>
        </div>
        <div className="bg-white rounded-lg shadow p-3">
          <h3 className="text-sm font-medium text-slate-500">Win Rate</h3>
          <p className="text-xl font-bold text-slate-900">{winRate.toFixed(1)}%</p>
        </div>
      </div>

      <div className="overflow-x-auto pb-4">
        <div className="flex gap-4 min-w-[1000px]">
          {stages.map(stage => (
            <div
              key={stage.label}
              className="flex-1 min-w-[260px] bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col"
            >
              <div className="flex items-center justify-between px-3 py-2 border-b bg-slate-100">
                <span className="font-semibold text-sm text-slate-800">{stage.label}</span>
                <span className="text-xs text-slate-800">{grouped[stage.label]?.length || 0} Deals</span>
              </div>

              <button
                className="text-xs text-primary-600 border-b border-slate-200 py-1.5 hover:bg-slate-100 transition"
                onClick={() => alert(`Add opportunity to ${stage.label}`)}
              >
                <Plus size={12} className="inline mr-1" /> Add Opportunity
              </button>

              <div className="p-2 flex-1 overflow-y-auto space-y-2 min-h-[80px]">
                {grouped[stage.label]?.length === 0 && (
                  <div className="text-center py-2 text-xs text-slate-500">
                    No opportunities in this stage
                  </div>
                )}

                {grouped[stage.label]?.map(opp => (
                  <div
                    key={opp.id}
                    className="rounded-lg border border-slate-200 bg-slate-50 p-2 hover:bg-slate-100 transition cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1">
                        <Briefcase className="h-4 w-4 text-slate-400" />
                        <span className="font-medium text-slate-900 text-sm">{opp.name}</span>
                      </div>
                      <span className="text-sm text-primary-600">${(opp.amount || 0).toLocaleString()}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1 text-xs text-slate-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" /> <span>{opp.closeDate}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="h-3 w-3" /> <span>{opp.contactName || 'N/A'}</span>
                      </div>
                    </div>
                    <div className="mt-1">
                      <div className="h-1.5 w-full bg-slate-200 rounded-full">
                        <div
                          className="h-1.5 bg-primary-600 rounded-full"
                          style={{ width: `${opp.probability || 0}%` }}
                        />
                      </div>
                      <div className="mt-1 text-xs text-right text-slate-500">{(opp.probability || 0)}% Probability</div>
                    </div>
                  </div>
                ))}
              </div>

              <button className="text-xs text-primary-600 border-t border-slate-200 py-1.5 hover:bg-slate-100 transition">
                <Plus size={12} className="inline mr-1" /> Add Opportunity
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OpportunityPipeline;
