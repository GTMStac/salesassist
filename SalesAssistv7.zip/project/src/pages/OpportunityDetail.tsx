import React, { useState } from "react";
import {
  ChevronRight, ChevronDown, Calendar, Briefcase, FileText, DollarSign, Tag, MapPin,
  Users, Edit2, Download, ExternalLink, Phone, CheckCircle, Star, Bell
} from "lucide-react";
import { Link } from "react-router-dom";

const stages = [
  "Prospecting",
  "Qualified",
  "Discovery",
  "Proposal Sent",
  "Negotiation",
  "Closed"
];

const products = [
  { name: "Basic License", qty: 10, unit: 80, discount: 0, total: 800 },
  { name: "Premium Support Package", qty: 1, unit: 500, discount: 10, total: 450 },
];

export default function OpportunityDetailPage() {
  const [activeTab, setActiveTab] = useState("Overview");
  const [currentStage, setCurrentStage] = useState(2); // Discovery

  return (
    <div className="bg-gradient-to-br from-blue-50/50 to-indigo-50/50 min-h-screen p-6 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <div>
          <Link to="/opportunities" className="text-blue-700 font-medium flex items-center gap-1 mb-2 hover:underline">
            <ChevronLeft className="h-4 w-4" /> Back to Opportunities
          </Link>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900 mb-1">SaaS Collaboration Tool Deal</h1>
          <div className="flex gap-2 mt-2">
            {["Overview", "Tasks", "Notes"].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-md font-semibold transition text-base
                  ${activeTab === tab
                    ? "bg-blue-50 text-blue-700 shadow-sm"
                    : "text-gray-400 hover:text-blue-700 hover:bg-blue-50"
                  }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
        <div className="flex gap-2">
          <button className="border border-gray-200 rounded-lg px-4 py-2 text-sm font-medium text-slate-700 bg-white/80 flex items-center gap-2 hover:bg-blue-50 transition">
            <ExternalLink className="h-4 w-4" /> View in Salesforce
          </button>
          <button className="border border-gray-200 rounded-lg px-4 py-2 text-sm font-medium text-slate-700 bg-white/80 flex items-center gap-2 hover:bg-blue-50 transition">
            <Download className="h-4 w-4" /> Generate PDF
          </button>
          <button className="border border-gray-200 rounded-lg px-4 py-2 text-sm font-medium text-slate-700 bg-white/80 flex items-center gap-2 hover:bg-blue-50 transition">
            <Edit2 className="h-4 w-4" /> Edit Opportunity
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Left/Main Column */}
        <div className="xl:col-span-2 flex flex-col gap-6">
          {/* Stages */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl border border-indigo-100 shadow p-6">
            <div className="mb-4 flex items-center justify-between">
              <span className="font-semibold text-slate-800">Stages</span>
              <button className="bg-gradient-to-br from-blue-600 to-indigo-600 text-white px-4 py-2 rounded-md font-semibold text-sm hover:shadow-lg hover:from-blue-700 hover:to-indigo-700 transition">
                Move to Next Stage
              </button>
            </div>
            <div className="flex items-center justify-between gap-2">
              {stages.map((stage, idx) => (
                <React.Fragment key={stage}>
                  <div className="flex flex-col items-center">
                    <div className={`h-5 w-5 rounded-full flex items-center justify-center
                      ${idx <= currentStage ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-400"}`}>
                      {idx < currentStage ? <CheckCircle className="h-4 w-4" /> : <span>{idx + 1}</span>}
                    </div>
                    <span className={`mt-2 text-xs font-medium ${idx === currentStage ? "text-blue-700" : "text-gray-400"}`}>{stage}</span>
                  </div>
                  {idx < stages.length - 1 && (
                    <div className={`flex-1 h-1 ${idx < currentStage ? "bg-blue-600" : "bg-gray-200"}`}></div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Opportunity Details */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl border border-indigo-100 shadow p-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <div className="text-xs text-gray-500 mb-1">Opportunity ID</div>
              <div className="font-semibold text-slate-800">OP-001</div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-1">Industry</div>
              <div className="font-semibold text-slate-800">Technology/Software</div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-1">Close Date</div>
              <div className="font-semibold text-slate-800">2024-12-05</div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-1">Probability of Closure</div>
              <div className="font-semibold text-slate-800">70%</div>
            </div>
          </div>

          {/* Financials */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl border border-indigo-100 shadow p-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <div className="text-xs text-gray-500 mb-1">Expected Revenue</div>
              <div className="font-semibold text-slate-800">$1,250</div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-1">Discount Offered</div>
              <div className="font-semibold text-slate-800">10%</div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-1">Subscription Details</div>
              <div className="font-semibold text-slate-800">$80/user/year</div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-1">Competitor Pricing</div>
              <div className="font-semibold text-slate-800">$85/user/year</div>
            </div>
          </div>

          {/* Activity */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl border border-indigo-100 shadow p-6">
            <div className="font-semibold text-slate-800 mb-4">Activity</div>
            <div className="flex flex-wrap gap-2 mb-4">
              <div className="flex items-center border rounded-md px-3 py-1 bg-gray-50 text-sm text-gray-500">
                <Calendar className="h-4 w-4 mr-1" /> Date Range: March 25 – July 25
              </div>
              <div className="flex items-center border rounded-md px-3 py-1 bg-gray-50 text-sm text-gray-500">
                <FileText className="h-4 w-4 mr-1" /> All Activity
              </div>
              <input
                className="border rounded-md px-3 py-1 bg-gray-50 text-sm text-gray-700"
                placeholder="Search activity..."
              />
            </div>
            {/* Activity log */}
            <div className="divide-y divide-gray-100">
              <div className="py-2 text-gray-500 font-medium">This Week</div>
              <div className="py-2 text-gray-400 text-sm">No activity recorded for this period.</div>
              <div className="py-2 text-gray-500 font-medium">Last Week</div>
              <div className="py-2 text-gray-400 text-sm">No activity recorded for this period.</div>
              <div className="py-2 flex items-start gap-3">
                <div className="flex flex-col items-center">
                  <Phone className="h-5 w-5 text-blue-600" />
                  <span className="text-xs text-gray-400">Mar 14</span>
                </div>
                <div>
                  <div className="text-gray-700 font-semibold">John scheduled a call</div>
                  <div className="text-xs text-gray-400">Apr 18, 2023 at 4:05PM</div>
                </div>
              </div>
              <div className="py-2 flex items-start gap-3">
                <div className="flex flex-col items-center">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <div className="text-gray-700 font-semibold">Opportunity created, discovery call completed.</div>
                  <div className="text-xs text-gray-400">Apr 18, 2023 at 4:05PM</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <aside className="flex flex-col gap-6">
          {/* Company */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl border border-indigo-100 shadow p-6 flex flex-col gap-2">
            <div className="font-semibold text-slate-800 mb-2">Company</div>
            <div className="flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-gray-400" />
              <span className="font-bold text-slate-900">Code Sphere</span>
              <span className="bg-gray-100 text-xs text-gray-600 px-2 py-0.5 rounded">Technology</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Tag className="h-4 w-4" /> Industry: Technology
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <MapPin className="h-4 w-4" /> Location: Indonesia
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Users className="h-4 w-4" /> Employee Range: 100k+
            </div>
          </div>

          {/* Subscription Status */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl border border-indigo-100 shadow p-6">
            <div className="font-semibold text-slate-800 mb-2">Subscription Status</div>
            <div className="flex justify-between text-sm text-gray-500 mb-1">
              <span>Start Date: Mar 15, 2024</span>
              <span>End Date: Mar 14, 2025</span>
            </div>
            <div className="w-full bg-gray-200 h-2 rounded-full mb-2">
              <div className="bg-blue-600 h-2 rounded-full" style={{ width: "100%" }}></div>
            </div>
            <div className="text-xs text-red-600 flex items-center gap-2">
              <span className="font-semibold">Expires today</span>
              <span className="text-red-500">Subscription nearing expiry. Plan renewal!</span>
            </div>
          </div>

          {/* Products */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl border border-indigo-100 shadow p-6">
            <div className="font-semibold text-slate-800 mb-2">Products (2)</div>
            <table className="w-full text-sm mb-3">
              <thead>
                <tr className="text-gray-400">
                  <th className="text-left py-1">Name</th>
                  <th className="text-right py-1">Qty</th>
                  <th className="text-right py-1">Unit Price</th>
                  <th className="text-right py-1">Discount</th>
                  <th className="text-right py-1">Total</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p, i) => (
                  <tr key={i} className="text-slate-700">
                    <td className="py-1">{p.name}</td>
                    <td className="py-1 text-right">{p.qty}</td>
                    <td className="py-1 text-right">${p.unit.toFixed(2)}</td>
                    <td className="py-1 text-right">{p.discount}%</td>
                    <td className="py-1 text-right">${p.total.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="flex flex-col gap-1 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Subtotal</span>
                <span className="text-slate-800 font-semibold">$1,300.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Total Discount</span>
                <span className="text-red-600 font-semibold">-$50.00</span>
              </div>
              <div className="flex justify-between text-base mt-2">
                <span className="font-bold text-slate-900">Grand Total</span>
                <span className="font-bold text-blue-700">$1,250.00</span>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

// Add missing icon import (if needed)
const ChevronLeft = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M15 18l-6-6 6-6" />
  </svg>
);
