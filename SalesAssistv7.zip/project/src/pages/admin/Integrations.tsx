import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { MessageSquare, CheckCircle2, XCircle } from 'lucide-react';

const Integrations = () => {
  const [salesforceEnv, setSalesforceEnv] = useState<'sandbox' | 'production' | ''>('');
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const navigate = useNavigate();

  // Helper to check for valid connection
  const checkConnection = () => {
    const accessToken = localStorage.getItem('sf_access_token');
    const instanceUrl = localStorage.getItem('sf_instance_url');
    return !!accessToken && !!instanceUrl;
  };

  useEffect(() => {
    setIsConnected(checkConnection());
  }, []);

  const handleConnect = async () => {
    try {
      console.log('[DEBUG] Starting Salesforce connection...');
      
      if (!salesforceEnv) {
        setError('Please select a Salesforce environment');
        return;
      }

      setError(null);
      setIsConnecting(true);

      // Validate environment variables
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseKey) {
        throw new Error('Missing Supabase configuration');
      }

      const apiUrl = `${supabaseUrl}/functions/v1/salesforce-token`;
      console.log('[DEBUG] API Endpoint:', apiUrl);

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`
        },
        body: JSON.stringify({ environment: salesforceEnv })
      });

      console.log('[DEBUG] Response Status:', response.status);

      const responseText = await response.text();
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (e) {
        throw new Error(`Invalid response: ${responseText.slice(0, 100)}`);
      }

      if (!response.ok) {
        const errorMessage = data.error_description || 
                            data.error || 
                            'Failed to connect to Salesforce';
        throw new Error(errorMessage);
      }

      if (!data.access_token || !data.instance_url) {
        throw new Error('Invalid token response from Salesforce');
      }

      // Store credentials
      localStorage.setItem('sf_access_token', data.access_token);
      localStorage.setItem('sf_instance_url', data.instance_url);
      localStorage.setItem('sf_environment', salesforceEnv);
      
      setIsConnected(true);
      setIsConnecting(false);

    } catch (err: any) {
      console.error('[ERROR] Connection failed:', err);
      setIsConnecting(false);
      
      const errorMessage = err.message.includes('JSON')
        ? 'Invalid response from server'
        : err.message;
      
      setError(errorMessage);
      
      // Clear invalid credentials
      localStorage.removeItem('sf_access_token');
      localStorage.removeItem('sf_instance_url');
    }
  };

  const handleDisconnect = () => {
    localStorage.removeItem('sf_access_token');
    localStorage.removeItem('sf_instance_url');
    localStorage.removeItem('sf_environment');
    setIsConnected(false);
    setError(null);
    navigate('/admin/integrations');
  };

  if (isConnecting) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[300px]">
        <svg className="animate-spin h-8 w-8 text-indigo-600 mb-4" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
        <span className="text-slate-700 font-medium">Connecting to Salesforce...</span>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <div className="flex items-center space-x-4 mb-6">
        <MessageSquare className="h-8 w-8 text-indigo-600" />
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Integrations</h1>
          <p className="text-slate-500">Connect your CRM and other tools</p>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-xl font-medium text-slate-900">Salesforce Integration</h2>
            <p className="text-sm text-slate-500">Connect to your Salesforce organization</p>
          </div>
          <span className={`inline-flex items-center text-sm font-medium px-3 py-1.5 rounded-full ${
            isConnected ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
            {isConnected ? (
              <>
                <CheckCircle2 className="w-4 h-4 mr-1" />
                Connected
              </>
            ) : (
              <>
                <XCircle className="w-4 h-4 mr-1" />
                Not Connected
              </>
            )}
          </span>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        {!isConnected ? (
          <div className="space-y-4">
            <div>
              <label className="block mb-1 font-medium text-slate-700">
                Select Environment
              </label>
              <select
                value={salesforceEnv}
                onChange={(e) => {
                  setSalesforceEnv(e.target.value as 'sandbox' | 'production' | '');
                  setError(null);
                }}
                className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              >
                <option value="">-- Select environment --</option>
                <option value="sandbox">Sandbox</option>
                <option value="production">Production</option>
              </select>
            </div>

            <button
              onClick={handleConnect}
              disabled={isConnecting}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Connect to Salesforce
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              Your Salesforce organization is connected. You can now use Salesforce features in the application.
            </p>
            <button
              onClick={handleDisconnect}
              className="inline-flex items-center px-4 py-2 border border-slate-300 text-sm font-medium rounded-md shadow-sm text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Disconnect
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Integrations;
