import React, { useState } from "react";
import { supabase } from "../supabaseClient";

export default function CreateProspectForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await supabase.from("prospects").insert([
      { name, email, status: "active", followup_count: 0, conversation: [] }
    ]);
    setName("");
    setEmail("");
    alert("Prospect added!");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} required />
      <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required />
      <button type="submit">Add Prospect</button>
    </form>
  );
}
