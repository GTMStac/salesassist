/*
  # OAuth States Table for PKCE Flow

  1. New Tables
    - `oauth_states`
      - `id` (uuid, primary key)
      - `code_verifier` (text, required) - Stores PKCE code verifier
      - `created_at` (timestamptz) - Creation timestamp
      - `expires_at` (timestamptz, required) - Expiration timestamp

  2. Security
    - Enable RLS on `oauth_states` table
    - Add policy for service role access
    - Drop existing policy if it exists
*/

-- Create the oauth_states table if it doesn't exist
CREATE TABLE IF NOT EXISTS oauth_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code_verifier text NOT NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL
);

-- Create an index on expires_at for cleanup queries
CREATE INDEX IF NOT EXISTS idx_oauth_states_expires_at ON oauth_states(expires_at);

-- Enable Row Level Security
ALTER TABLE oauth_states ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Service role can manage oauth states" ON oauth_states;

-- Add policy for service role access
CREATE POLICY "Service role can manage oauth states"
  ON oauth_states
  FOR ALL
  TO public
  USING (auth.jwt() ->> 'role' = 'service_role');