/*
  # OAuth States Table

  1. New Tables
    - `oauth_states`
      - `id` (uuid, primary key)
      - `code_verifier` (text, required)
      - `created_at` (timestamptz)
      - `expires_at` (timestamptz, required)
  
  2. Security
    - Enable RLS on `oauth_states` table
  
  3. Performance
    - Add index on expires_at for faster lookups and cleanup
*/

CREATE TABLE IF NOT EXISTS oauth_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code_verifier text NOT NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL
);

ALTER TABLE oauth_states ENABLE ROW LEVEL SECURITY;

-- Add index for faster lookups and cleanup
CREATE INDEX IF NOT EXISTS idx_oauth_states_expires_at ON oauth_states(expires_at);