/*
  # OAuth States Table for PKCE Flow

  1. New Tables
    - `oauth_states`
      - `id` (uuid, primary key)
      - `code_verifier` (text, required) - Stores PKCE code verifier
      - `created_at` (timestamptz) - Creation timestamp
      - `expires_at` (timestamptz, required) - Expiration timestamp

  2. Security
    - Enable RLS on `oauth_states` table
    - Add index for faster lookups and cleanup

  3. Changes
    - Add table for storing PKCE code verifiers
    - Add expiration timestamp for cleanup
*/

CREATE TABLE IF NOT EXISTS oauth_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code_verifier text NOT NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL
);

ALTER TABLE oauth_states ENABLE ROW LEVEL SECURITY;

-- Add index for faster lookups and cleanup
CREATE INDEX IF NOT EXISTS idx_oauth_states_expires_at ON oauth_states(expires_at);

-- Add policy for service role access
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'oauth_states' 
    AND policyname = 'Service role can manage oauth states'
  ) THEN
    CREATE POLICY "Service role can manage oauth states"
      ON oauth_states
      USING (auth.role() = 'service_role');
  END IF;
END $$;