/*
  # Create OAuth States Table

  1. New Tables
    - `oauth_states`
      - `id` (uuid, primary key)
      - `code_verifier` (text, required)
      - `created_at` (timestamp with timezone)
      - `expires_at` (timestamp with timezone)

  2. Security
    - Enable RLS on `oauth_states` table
    - Add policy for service role access only
*/

CREATE TABLE IF NOT EXISTS oauth_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code_verifier text NOT NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL
);

ALTER TABLE oauth_states ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Service role can manage oauth states"
  ON oauth_states
  USING (auth.role() = 'service_role');

-- Add index for faster lookups and cleanup
CREATE INDEX IF NOT EXISTS idx_oauth_states_expires_at ON oauth_states(expires_at);