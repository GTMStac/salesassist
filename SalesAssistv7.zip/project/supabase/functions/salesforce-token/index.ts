import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type, apikey, sf-instance-url, sf-user-id",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const path = url.pathname.split('/').pop();

  try {
    switch (path) {
      case 'opportunities':
        return await handleOpportunities(req);
      case 'leads':
        return await handleLeads(req);
      case 'contacts':
        return await handleContacts(req);
      case 'accounts':
        return await handleAccounts(req);
        case 'activities':
        return await handleActivities(req);
      case 'calls':
        return await handleCalls(req);
      case 'emails':
        return await handleEmails(req);
      case 'tasks':
        return await handleTasks(req);
      case 'events':
        return await handleEvents(req);
      default:
        return await handleToken(req);
    }
  } catch (error) {
    console.error(`Error in ${path || 'token'} endpoint:`, error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function handleToken(req: Request) {
  const { environment } = await req.json();
  if (!environment) {
    return new Response(
      JSON.stringify({ error: "Missing Salesforce environment" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const clientId = Deno.env.get("SF_CLIENT_ID");
  const clientSecret = Deno.env.get("SF_CLIENT_SECRET");
  if (!clientId || !clientSecret) {
    return new Response(
      JSON.stringify({ error: "Missing Salesforce credentials" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const tokenUrl = environment === "sandbox"
    ? "https://glean--gleanit.sandbox.my.salesforce.com/services/oauth2/token"
    : "https://login.salesforce.com/services/oauth2/token";

  const params = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret,
  });

  const tokenRes = await fetch(tokenUrl, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });

  const text = await tokenRes.text();
  let tokenData;
  try {
    tokenData = JSON.parse(text);
  } catch {
    return new Response(
      JSON.stringify({ error: "Invalid response from Salesforce", details: text }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  if (!tokenRes.ok || tokenData.error) {
    return new Response(
      JSON.stringify({ error: tokenData.error_description || "Authentication failed", details: tokenData }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  return new Response(JSON.stringify(tokenData), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function fetchSalesforceData(req: Request, soqlBase: string) {
  const accessToken = req.headers.get("authorization")?.replace("Bearer ", "");
  const instanceUrl = req.headers.get("sf-instance-url");
  const salesforceUserId = req.headers.get("sf-user-id");

  if (!accessToken || !instanceUrl || !salesforceUserId) {
    return new Response(
      JSON.stringify({ error: "Missing Salesforce credentials or user ownership" }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  // Proper WHERE clause insertion
  let modifiedSoql = soqlBase;
  if (!soqlBase.toLowerCase().includes("where")) {
    modifiedSoql = soqlBase.replace(/(FROM\s+\w+)/i, `$1 WHERE OwnerId = '${salesforceUserId}'`);
  } else {
    modifiedSoql = soqlBase.replace(/WHERE/i, `WHERE OwnerId = '${salesforceUserId}' AND `);
  }

  const encodedSoql = encodeURIComponent(modifiedSoql);
  const sfRes = await fetch(`${instanceUrl}/services/data/v60.0/query/?q=${encodedSoql}`, {
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    }
  });

  const text = await sfRes.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    return new Response(
      JSON.stringify({ error: "Invalid response from Salesforce", details: text }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  if (!sfRes.ok) {
    return new Response(
      JSON.stringify({ error: data.error || "Salesforce API error", details: data }),
      { status: sfRes.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  return new Response(JSON.stringify(data), {
    headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
}

async function handleOpportunities(req: Request) {
  const soqlBase = `
    SELECT Id, Name, StageName, Amount, CloseDate, Probability, Type, AccountId, Account.Name
    FROM Opportunity
    ORDER BY CloseDate DESC
    LIMIT 100
  `;
  return fetchSalesforceData(req, soqlBase);
}

async function handleLeads(req: Request) {
  const accessToken = req.headers.get("authorization")?.replace("Bearer ", "");
  const instanceUrl = req.headers.get("sf-instance-url");
  const salesforceUserId = req.headers.get("sf-user-id");

  if (!accessToken || !instanceUrl || !salesforceUserId) {
    return new Response(
      JSON.stringify({ error: "Missing Salesforce credentials or user ownership" }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  if (req.method === "POST") {
    // CREATE LEAD in Salesforce
    let body;
    try {
      body = await req.json();
    } catch {
      return new Response(
        JSON.stringify({ error: "Invalid JSON body" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Prepare payload for Salesforce
    const payload = {
      FirstName: body.FirstName,
      LastName: body.LastName,
      Company: body.Company,
      Phone: body.Phone,
      Email: body.Email,
      Title: body.Title,
      Status: body.Status,
      OwnerId: salesforceUserId // Ensure the lead is assigned to the current user
    };

    const sfRes = await fetch(`${instanceUrl}/services/data/v60.0/sobjects/Lead/`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const text = await sfRes.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return new Response(
        JSON.stringify({ error: "Invalid response from Salesforce", details: text }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!sfRes.ok) {
      return new Response(
        JSON.stringify({ error: data?.message || data.error || "Salesforce API error", details: data }),
        { status: sfRes.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(JSON.stringify(data), {
      status: 201,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }

  // Default: GET (fetch leads)
  const soqlBase = `
    SELECT Id, FirstName, LastName, Company, Title, Email, Phone, Status
    FROM Lead
    ORDER BY CreatedDate DESC
    LIMIT 100
  `;
  return fetchSalesforceData(req, soqlBase);
}

async function handleContacts(req: Request) {
  const soqlBase = `
    SELECT Id, FirstName, LastName, AccountId, Email, Phone, Title
    FROM Contact
    ORDER BY CreatedDate DESC
    LIMIT 100
  `;
  return fetchSalesforceData(req, soqlBase);
}

async function handleAccounts(req: Request) {
  const accessToken = req.headers.get("authorization")?.replace("Bearer ", "");
  const instanceUrl = req.headers.get("sf-instance-url");
  const salesforceUserId = req.headers.get("sf-user-id");

  if (!accessToken || !instanceUrl || !salesforceUserId) {
    return new Response(
      JSON.stringify({ error: "Missing Salesforce credentials or user ownership" }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  if (req.method === "POST") {
    // CREATE ACCOUNT in Salesforce
    let body;
    try {
      body = await req.json();
    } catch {
      return new Response(
        JSON.stringify({ error: "Invalid JSON body" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Prepare payload for Salesforce
    const payload = {
      Name: body.Name,
      Industry: body.Industry,
      Website: body.Website,
      Phone: body.Phone,
      Type: body.Type,
      BillingCity: body.BillingCity,
      BillingCountry: body.BillingCountry,
      OwnerId: salesforceUserId
    };

    const sfRes = await fetch(`${instanceUrl}/services/data/v60.0/sobjects/Account/`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const text = await sfRes.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return new Response(
        JSON.stringify({ error: "Invalid response from Salesforce", details: text }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!sfRes.ok) {
      return new Response(
        JSON.stringify({ error: data?.message || data.error || "Salesforce API error", details: data }),
        { status: sfRes.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(JSON.stringify(data), {
      status: 201,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }

  // Default: GET (fetch accounts)
  const soqlBase = `
    SELECT Id, Name, Industry, Website, Phone, Type, BillingCity, BillingCountry
    FROM Account
    ORDER BY CreatedDate DESC
    LIMIT 100
  `;
  return fetchSalesforceData(req, soqlBase);

// --- Activity Endpoints ---

async function handleActivities(req: Request) {
  // All Tasks (including Calls, Emails, Tasks) + Events
  const soqlBase = `
    SELECT Id, Subject, ActivityDate, Status, Priority, Description, OwnerId, WhatId, WhoId, TaskSubtype, Type, CallType, CallDisposition, CallDurationInSeconds
    FROM Task
    WHERE IsDeleted = false
    ORDER BY ActivityDate DESC
    LIMIT 100
  `;
  return fetchSalesforceData(req, soqlBase);
}

async function handleCalls(req: Request) {
  // Calls are Tasks with Type = 'Call' or TaskSubtype = 'Call'
  const soqlBase = `
    SELECT Id, Subject, ActivityDate, Status, Priority, Description, OwnerId, WhatId, WhoId, TaskSubtype, Type, CallType, CallDisposition, CallDurationInSeconds
    FROM Task
    WHERE (Type = 'Call' OR TaskSubtype = 'Call') AND IsDeleted = false
    ORDER BY ActivityDate DESC
    LIMIT 100
  `;
  return fetchSalesforceData(req, soqlBase);
}

async function handleEmails(req: Request) {
  // Emails can be in Task (TaskSubtype = 'Email')
  const soqlBase = `
    SELECT Id, Subject, ActivityDate, Status, Priority, Description, OwnerId, WhatId, WhoId, TaskSubtype, Type
    FROM Task
    WHERE TaskSubtype = 'Email' AND IsDeleted = false
    ORDER BY ActivityDate DESC
    LIMIT 100
  `;
  return fetchSalesforceData(req, soqlBase);
}

async function handleTasks(req: Request) {
  // Tasks only (not calls/emails)
  const soqlBase = `
    SELECT Id, Subject, ActivityDate, Status, Priority, Description, OwnerId, WhatId, WhoId, TaskSubtype, Type
    FROM Task
    WHERE TaskSubtype = 'Task' AND IsDeleted = false
    ORDER BY ActivityDate DESC
    LIMIT 100
  `;
  return fetchSalesforceData(req, soqlBase);
}

async function handleEvents(req: Request) {
  const soqlBase = `
    SELECT Id, Subject, StartDateTime, EndDateTime, Description, OwnerId, WhatId, WhoId, Location
    FROM Event
    WHERE IsDeleted = false
    ORDER BY StartDateTime DESC
    LIMIT 100
  `;
  return fetchSalesforceData(req, soqlBase);
}

export { corsHeaders };
